---
name: Workflow navigation
description: How navigation should behave when a later workspace step depends on missing work.
---

Make every visible navigation control perform a real action. Let users return to completed steps, but guide them to the earliest missing prerequisite when a later step needs data that does not yet exist. Do not generate sample analysis or pretend a contract is ready just to satisfy a navigation click.

**Why:** The user explicitly rejected non-clickable navigation and mock interactions. A clickable label that silently skips missing analysis would solve the first problem by creating the second.

**How to apply:** For new Brand or Creator steps, define the prerequisite and return path together with the navigation item. If a supporting feature such as notifications or accounts does not exist, do not display a button that implies it does.