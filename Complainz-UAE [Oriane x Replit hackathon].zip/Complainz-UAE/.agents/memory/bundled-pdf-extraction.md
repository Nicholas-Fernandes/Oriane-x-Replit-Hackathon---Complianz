---
name: Bundled PDF extraction
description: Why PDF.js needs special runtime setup when used in the bundled API server.
---

When using PDF.js for server-side extraction in the bundled Node service, keep its native canvas runtime available and resolve its worker from the installed package rather than relying on PDF.js's relative default.

**Why:** TypeScript checks and the server bundle both succeeded while startup crashed without the canvas runtime; after that was supplied, extraction failed because PDF.js looked for its worker beside the bundled server output. This is a runtime packaging constraint, not a malformed uploaded PDF.

**How to apply:** After changing the PDF dependency or server bundler, check both server startup and extraction of a real text-based PDF through the proxied API. Do not treat a typecheck alone as proof that PDF parsing works.