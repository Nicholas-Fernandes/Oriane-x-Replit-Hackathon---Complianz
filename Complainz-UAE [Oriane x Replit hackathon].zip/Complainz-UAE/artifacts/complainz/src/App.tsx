import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  useLookupOriane,
  type OrianeLookupResult,
} from '@workspace/api-client-react';
import {
  ArrowLeft,
  ArrowRight,
  BadgeCheck,
  Bell,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  ClipboardCheck,
  ClipboardCopy,
  CloudUpload,
  Copy,
  Download,
  FileCheck2,
  FileText,
  Globe2,
  Instagram,
  LayoutDashboard,
  LoaderCircle,
  Link2,
  Mail,
  Menu,
  MessageSquareText,
  MoreHorizontal,
  PenLine,
  Plus,
  Search,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Store,
  ToggleLeft,
  ToggleRight,
  Trash2,
  UserRound,
  Users,
  X,
  Zap,
} from 'lucide-react';
import { Link, Route, Switch, useLocation, useRoute } from 'wouter';
import type { ContractAnalysis } from '@workspace/api-client-react';
import { CreatorPdfUpload, CreatorPdfAnalysis } from './CreatorReview';
import DemoSigningRoom from './DemoSigningRoom';
import { BrandEmailPreview } from './BrandEmailPreview';

type Mode = 'brand' | 'creator';
type CreatorKey = 'sara' | 'wildcard' | 'live';
type RiskTone = 'low' | 'medium' | 'high';
type RiskFactor = { label: string; wild: string; sara: string; tone: RiskTone };

type Creator = {
  key: CreatorKey;
  handle: string;
  name: string;
  platform: string;
  niche: string;
  followers: string;
  engagement: string;
  risk: number;
  riskTone: RiskTone;
  accent: string;
  initials: string;
  summary: string;
  source?: 'seeded' | 'live';
  liveRiskFactors?: RiskFactor[];
};

const creators: Record<'sara' | 'wildcard', Creator> = {
  sara: {
    key: 'sara',
    handle: '@sara.glow',
    name: 'Sara Al Nuaimi',
    platform: 'Instagram',
    niche: 'Beauty, wellness',
    followers: '184.2K',
    engagement: '4.8%',
    risk: 1,
    riskTone: 'low',
    accent: 'from-[#dceff1] to-[#c7d8ef]',
    initials: 'SG',
    summary: 'A dependable brand partner with clear disclosures and a clean collaboration history.',
    source: 'seeded',
  },
  wildcard: {
    key: 'wildcard',
    handle: '@dxb.wildcard',
    name: 'Omar Khalid',
    platform: 'TikTok',
    niche: 'Streetwear, nightlife',
    followers: '72.8K',
    engagement: '7.1%',
    risk: 4,
    riskTone: 'high',
    accent: 'from-[#f4d9c8] to-[#e8bbc1]',
    initials: 'DW',
    summary: 'High reach, but unresolved content and disclosure signals need a decision before briefing.',
    source: 'seeded',
  },
};

const riskFactors = [
  { label: 'Advertising disclosure', wild: '3 missing disclosures found', sara: 'Clear on 18/18 reviewed posts', tone: 'high' },
  { label: 'Restricted content', wild: '2 posts flagged for alcohol promotion', sara: 'No restricted content detected', tone: 'medium' },
  { label: 'Brand safety', wild: 'One unresolved comment thread', sara: 'No safety concerns found', tone: 'low' },
  { label: 'Audience authenticity', wild: '89% authentic audience', sara: '94% authentic audience', tone: 'low' },
];

function formatCompactNumber(value: number) {
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M`;
  if (value >= 1_000) return `${(value / 1_000).toFixed(value >= 100_000 ? 0 : 1)}K`;
  return value.toLocaleString();
}

function formatRate(value: number) {
  const percent = value <= 1 ? value * 100 : value;
  return `${percent.toFixed(1)}%`;
}

function toLiveCreator(data: OrianeLookupResult): Creator | null {
  if (!data.profile) return null;
  const profile = data.profile;
  const videos = data.videos;
  const disclosureCount = videos.filter((video) => {
    const caption = video.caption ?? '';
    const sponsoredSignal = video.mentions.length > 0 || video.coAuthors.length > 0;
    return sponsoredSignal && !/(#ad|#sponsored|paid partnership|paidpartnership)/i.test(caption);
  }).length;
  const restrictedCount = videos.filter((video) => /(alcohol|vape|vaping|tobacco|gambl|narcotic)/i.test(video.caption ?? '')).length;
  const authenticityConcern = videos.length > 0 && videos.every((video) => video.erPerFollowers < 0.01);
  const score = Math.min(5, Math.max(videos.length < 3 ? 4 : 1, 1 + disclosureCount + restrictedCount + (authenticityConcern ? 1 : 0)));
  const riskTone: RiskTone = score >= 4 ? 'high' : score >= 3 ? 'medium' : 'low';
  const averageEngagement = videos.length
    ? videos.reduce((total, video) => total + video.erPerViews, 0) / videos.length
    : 0;
  const platform = profile.platform === 'tiktok' ? 'TikTok' : 'Instagram';
  const displayName = profile.displayName || `@${profile.handle}`;
  const initials = displayName.split(/\s+/).map((part) => part[0]).join('').slice(0, 2).toUpperCase();
  const liveRiskFactors: RiskFactor[] = [
    {
      label: 'Advertising disclosure',
      wild: disclosureCount ? `${disclosureCount} recent post${disclosureCount === 1 ? '' : 's'} need a disclosure review` : 'No missing disclosure signals found in returned content',
      sara: '',
      tone: disclosureCount ? 'high' : 'low',
    },
    {
      label: 'Restricted content',
      wild: restrictedCount ? `${restrictedCount} recent post${restrictedCount === 1 ? '' : 's'} matched restricted-category terms` : 'No restricted-category terms found in returned captions',
      sara: '',
      tone: restrictedCount ? 'high' : 'low',
    },
    {
      label: 'Recent content coverage',
      wild: videos.length ? `${videos.length} indexed post${videos.length === 1 ? '' : 's'} returned from the last 3 months` : 'No recent content returned; request more evidence before approving',
      sara: '',
      tone: videos.length >= 3 ? 'low' : 'medium',
    },
    {
      label: 'Engagement signal',
      wild: videos.length ? `Average engagement per view is ${formatRate(averageEngagement)}` : 'No engagement sample available',
      sara: '',
      tone: videos.length ? 'low' : 'medium',
    },
  ];

  return {
    key: 'live',
    handle: profile.handle.startsWith('@') ? profile.handle : `@${profile.handle}`,
    name: displayName,
    platform,
    niche: profile.bio || 'Live Oriane profile',
    followers: formatCompactNumber(profile.followersCount),
    engagement: videos.length ? formatRate(averageEngagement) : '—',
    risk: score,
    riskTone,
    accent: 'from-[#d8ebee] to-[#c9d9ef]',
    initials: initials || 'OR',
    summary: videos.length
      ? `Live profile data from Oriane with ${videos.length} recent ${platform} posts in scope. Review the evidence before approving a brief.`
      : 'Oriane found the profile, but returned no recent posts. Treat the report as incomplete.',
    source: 'live',
    liveRiskFactors,
  };
}

const contractFindings = [
  { id: 'disclosure', title: 'Disclosure is missing from the posting clause', status: 'Fix needed', quote: 'Creator shall publish the content as requested by the brand.', explanation: 'The contract needs a clear UAE advertising disclosure requirement for every sponsored post.', fix: 'Add: “Creator will visibly disclose the paid partnership on each sponsored deliverable.”' },
  { id: 'usage', title: 'Unlimited usage rights', status: 'Review', quote: 'Brand may use content in perpetuity across all media worldwide.', explanation: 'Perpetual, worldwide usage is a major transfer of value and is not priced into the current fee.', fix: 'Limit use to 90 days, UAE digital channels, and the named campaign.' },
  { id: 'exclusivity', title: 'Broad exclusivity window', status: 'Fix needed', quote: 'Creator shall not work with competing brands for 24 months.', explanation: 'Two years across an undefined competitor set could block the creator’s main income stream.', fix: 'Limit exclusivity to 60 days and list named competitors.' },
  { id: 'payment', title: 'Payment timing is unclear', status: 'Review', quote: 'Payment will be made after content approval.', explanation: 'There is no approval deadline, which leaves payment timing open-ended.', fix: 'Set payment within 15 business days of the first approved deliverable.' },
];

function cx(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(' ');
}

function usePersistentState<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const saved = localStorage.getItem(key);
      return saved ? (JSON.parse(saved) as T) : initial;
    } catch {
      return initial;
    }
  });
  useEffect(() => {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* demo mode */ }
  }, [key, value]);
  return [value, setValue] as const;
}

function Wordmark({ compact = false }: { compact?: boolean }) {
  return (
    <span className={cx('brand-wordmark', compact ? 'text-lg' : 'text-2xl')} aria-label="COMPLAINZ">
      COMPL<span className="ai">AI</span>NZ
    </span>
  );
}

function Avatar({ creator, small = false }: { creator: Creator; small?: boolean }) {
  return (
    <div className={cx('flex shrink-0 items-center justify-center rounded-full bg-gradient-to-br font-bold text-[#21334a]', small ? 'h-8 w-8 text-[10px]' : 'h-12 w-12 text-xs', creator.accent)} aria-label={`${creator.name} avatar`}>
      {creator.initials}
    </div>
  );
}

function FooterNote() {
  return <footer className="footer-note mt-auto px-5 py-4 text-center">Compliance checklist, not legal advice. Have contracts reviewed by a UAE lawyer.</footer>;
}

function Topbar({ mode, title, onMenu, live = false }: { mode?: Mode; title?: string; onMenu?: () => void; live?: boolean }) {
  const [, setLocation] = useLocation();
  return (
    <header className="flex min-h-[68px] items-center justify-between border-b border-[hsl(var(--border))] bg-white/90 px-4 sm:px-7">
      <div className="flex items-center gap-4">
        {onMenu && <button type="button" className="rounded-lg p-2 md:hidden" aria-label="Open navigation" data-testid="button-open-navigation" onClick={onMenu}><Menu size={19} /></button>}
        <button type="button" onClick={() => setLocation('/')} className="flex items-center" aria-label="Go to COMPLAINZ home" data-testid="button-home"><Wordmark compact /></button>
        {title && <><div className="hidden h-5 w-px bg-[hsl(var(--border))] sm:block" /><span className="hidden text-sm font-semibold text-[hsl(var(--muted-foreground))] sm:block">{title}</span></>}
      </div>
      <div className="flex items-center gap-2.5">
        <span className="hidden items-center gap-1.5 rounded-full bg-[#eef7f5] px-2.5 py-1 text-[11px] font-bold text-[#19745e] sm:flex"><span className="h-1.5 w-1.5 rounded-full bg-[#2baf83]" />{mode === 'creator' ? 'AI PDF review' : live ? 'Live workspace' : 'Demo workspace'}</span>
        {mode && <Link href={mode === 'brand' ? '/creator' : '/brand'} className="btn-secondary !px-3 !py-2 text-xs" data-testid="link-switch-workspace">
          {mode === 'brand' ? 'Creator workspace' : 'Brand workspace'} <ArrowRight size={14} />
        </Link>}
      </div>
    </header>
  );
}

function WorkspaceNav({ mode, step, onNavigate, onClose }: { mode: Mode; step: number; onNavigate: (step: number) => void; onClose?: () => void }) {
  const [, setLocation] = useLocation();
  const labels = mode === 'brand' ? ['Choose creator', 'Find creator', 'Vetting report', 'Campaign setup', 'Contract'] : ['Upload contract', 'Analysis'];
  return (
    <aside className="flex h-full min-h-[calc(100dvh-68px)] w-[250px] shrink-0 flex-col border-r border-[#243a52] bg-[hsl(var(--sidebar))] text-[hsl(var(--sidebar-foreground))]">
      <div className="flex items-center justify-between border-b border-[#243a52] px-5 py-5">
        <button type="button" onClick={() => setLocation('/')} aria-label="Home" data-testid="button-sidebar-home"><Wordmark compact /></button>
        {onClose && <button type="button" onClick={onClose} className="rounded-md p-1 md:hidden" aria-label="Close navigation" data-testid="button-close-navigation"><X size={17} /></button>}
      </div>
      <div className="px-4 py-5">
        <div className="mb-5 px-2"><p className="eyebrow !text-[#76c8db]">{mode === 'creator' ? 'Creator contract review' : 'Demo workspace'}</p><p className="mt-1 text-xs text-[#91a3b7]">UAE compliance desk</p></div>
        <nav className="space-y-1.5" aria-label="Workflow">
          {labels.map((label, index) => (
            <button key={label} type="button" onClick={() => onNavigate(index + 1)} aria-current={step === index + 1 ? 'step' : undefined} className={cx('flex w-full items-center gap-3 rounded-lg px-3 py-3 text-left text-sm transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#78c9dc]', step === index + 1 ? 'bg-[#203a55] font-bold text-white' : 'text-[#9aabbd] hover:bg-[#203a55] hover:text-white')} data-testid={`button-nav-${mode}-${index + 1}`}>
              <span className={cx('flex h-6 w-6 items-center justify-center rounded-full border text-[10px]', step > index + 1 ? 'border-[#57b99b] bg-[#57b99b] text-[#103b34]' : step === index + 1 ? 'border-[#78c9dc] text-[#78c9dc]' : 'border-[#41556a]')}>{step > index + 1 ? <Check size={13} /> : index + 1}</span>
              <span>{label}</span>
            </button>
          ))}
        </nav>
      </div>
      <div className="mt-auto p-4">
        <div className="rounded-xl border border-[#29445f] bg-[#1a3048] p-3.5">
          <div className="mb-2 flex items-center gap-2 text-xs font-bold text-[#d2e4ed]"><ShieldCheck size={15} className="text-[#6dc5b2]" />{mode === 'creator' ? 'Your PDF review' : 'Scope of this demo'}</div>
          <p className="text-[11px] leading-relaxed text-[#91a7ba]">{mode === 'creator' ? 'Upload a text-based PDF. AI suggestions require human review.' : 'Instagram + TikTok · last 3 months · accounts with 5K+ followers'}</p>
        </div>
      </div>
    </aside>
  );
}

function ProgressHeader({ step, total, mode }: { step: number; total: number; mode: Mode }) {
  return (
    <div className="mb-7 flex items-center justify-between gap-4">
      <div><p className="eyebrow">{mode === 'brand' ? 'Brand workspace' : 'Creator workspace'}</p><p className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">Step {step} of {total}</p></div>
      <div className="flex gap-1.5" aria-label={`Step ${step} of ${total}`}>
        {Array.from({ length: total }, (_, index) => <span key={index} className={cx('step-dot w-5', step === index + 1 && 'active', step > index + 1 && 'done')} />)}
      </div>
    </div>
  );
}

function Toast({ text, onClose }: { text: string; onClose: () => void }) {
  return <div className="fixed bottom-5 left-1/2 z-50 flex -translate-x-1/2 items-center gap-3 rounded-xl bg-[#192d42] px-4 py-3 text-sm font-semibold text-white shadow-2xl"><CheckCircle2 size={17} className="text-[#75d0b5]" />{text}<button type="button" onClick={onClose} aria-label="Dismiss notification" data-testid="button-dismiss-toast"><X size={14} /></button></div>;
}

function Landing() {
  const [, setLocation] = useLocation();
  return (
    <div className="app-shell flex flex-col">
      <header className="flex items-center justify-between px-5 py-5 sm:px-10">
        <Wordmark />
        <div className="flex items-center gap-3 text-xs font-semibold text-[hsl(var(--muted-foreground))]"><span className="hidden sm:inline">UAE compliance workspace</span><a href="#choose-workspace" className="btn-secondary !px-3 !py-2 text-xs" data-testid="button-landing-help"><ArrowRight size={14} />Get started</a></div>
      </header>
      <main className="section-wrap flex w-full flex-1 flex-col pb-10 pt-10 sm:pt-20">
        <section className="grid items-center gap-12 lg:grid-cols-[1.05fr_.95fr]">
          <div className="animate-rise">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-[#b7d8dd] bg-[#eef8f8] px-3 py-1.5 text-xs font-bold text-[#146b78]"><Sparkles size={14} />Make the confident call</div>
            <h1 className="max-w-2xl font-display text-5xl font-extrabold leading-[1.03] tracking-[-.055em] text-[#172536] sm:text-7xl">Know who you’re paying.<br /><span className="text-[hsl(var(--primary))]">Know what you’re signing.</span></h1>
            <p className="mt-6 max-w-xl text-base leading-7 text-[hsl(var(--muted-foreground))] sm:text-lg">COMPLAINZ turns creator compliance into a clear decision — before money, reputation, or legal exposure changes hands.</p>
            <div className="mt-8 flex flex-wrap items-center gap-3 text-xs font-semibold text-[hsl(var(--muted-foreground))]"><span className="flex items-center gap-1.5"><ShieldCheck size={15} className="text-[#19916e]" />UAE-ready checks</span><span className="h-4 w-px bg-[hsl(var(--border))]" /><span className="flex items-center gap-1.5"><Zap size={15} className="text-[#c88918]" />Built for decisions</span></div>
          </div>
          <div className="soft-grid relative overflow-hidden rounded-[1.5rem] border border-[#ccdae2] bg-[#f1f6f8] p-5 shadow-[var(--shadow-lift)] animate-rise delay-1 sm:p-7">
            <div className="absolute -right-16 -top-16 h-48 w-48 rounded-full bg-[#c9e8e9] blur-2xl" />
            <div className="relative rounded-xl border border-[#d7e2e7] bg-white p-4 shadow-sm sm:p-5">
              <div className="flex items-center justify-between border-b border-[hsl(var(--border))] pb-4"><div className="flex items-center gap-3"><div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#e8f2f5] text-[#246480]"><ClipboardCheck size={18} /></div><div><p className="text-sm font-bold">Creator decision brief</p><p className="text-[11px] text-[hsl(var(--muted-foreground))]">Campaign / FW24 launch</p></div></div><span className="rounded-full bg-[#e9f7f2] px-2 py-1 text-[10px] font-bold text-[#197b62]">Ready to decide</span></div>
              <div className="grid grid-cols-[1fr_auto] items-center gap-4 py-5"><div><p className="text-lg font-extrabold tracking-tight">@sara.glow</p><p className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">Instagram · 184.2K followers</p></div><div className="flex h-14 w-14 items-center justify-center rounded-full border-[5px] border-[#6fc4a8] text-lg font-extrabold text-[#16755b]">1<span className="text-[10px] font-semibold text-[hsl(var(--muted-foreground))]">/5</span></div></div>
              <div className="grid gap-2 sm:grid-cols-3"><MiniMetric label="Disclosure" value="Clear" tone="good" /><MiniMetric label="Audience" value="94% real" tone="good" /><MiniMetric label="Decision" value="Proceed" tone="blue" /></div>
            </div>
            <p className="relative mt-4 text-center text-[11px] font-semibold text-[#617887]">One workspace from first search to signed contract.</p>
          </div>
        </section>
        <section id="choose-workspace" className="mt-16 scroll-mt-8 border-t border-[hsl(var(--border))] pt-8 sm:mt-24">
          <div className="mb-5 flex items-end justify-between"><div><p className="eyebrow">Start with your side of the table</p><h2 className="mt-2 font-display text-2xl font-extrabold tracking-tight sm:text-3xl">What are you protecting today?</h2></div><span className="hidden text-xs text-[hsl(var(--muted-foreground))] sm:block">No account needed for this demo</span></div>
          <div className="grid gap-4 md:grid-cols-2">
            <ModeCard mode="brand" icon={<Store size={21} />} title="I represent a brand or agency" description="Vet a creator, define the brief, and generate a contract you can defend." action={() => setLocation('/brand')} />
            <ModeCard mode="creator" icon={<UserRound size={21} />} title="I’m a creator" description="Understand your contract before you sign — and ask for the changes that matter." action={() => setLocation('/creator')} />
          </div>
        </section>
        <section className="mt-16 grid gap-5 border-t border-[hsl(var(--border))] pt-8 sm:grid-cols-3 sm:pt-10">
          <TrustItem icon={<ShieldCheck size={18} />} title="Decision-grade" body="Evidence first, with a simple risk score your team can act on." />
          <TrustItem icon={<Globe2 size={18} />} title="Made for the UAE" body="Designed around local disclosure, permits, and contract realities." />
          <TrustItem icon={<FileCheck2 size={18} />} title="No black boxes" body="Every recommendation comes with the reason and the fix." />
        </section>
      </main>
      <FooterNote />
    </div>
  );
}

function ModeCard({ mode, icon, title, description, action }: { mode: Mode; icon: ReactNode; title: string; description: string; action: () => void }) {
  return <button type="button" onClick={action} className="group flex items-start justify-between rounded-2xl border border-[hsl(var(--border))] bg-white p-5 text-left shadow-[var(--shadow-soft)] transition-transform hover:-translate-y-1 hover:border-[#8db8c2] hover:shadow-[var(--shadow-lift)] sm:p-6" data-testid={`button-select-${mode}-mode`}><div><div className={cx('mb-5 flex h-10 w-10 items-center justify-center rounded-xl', mode === 'brand' ? 'bg-[#eaf1fb] text-[#2466a1]' : 'bg-[#edf6f0] text-[#277d5e]')}>{icon}</div><h3 className="font-display text-lg font-extrabold tracking-tight">{title}</h3><p className="mt-2 max-w-sm text-sm leading-6 text-[hsl(var(--muted-foreground))]">{description}</p></div><ArrowRight className="mt-1 text-[hsl(var(--muted-foreground))] transition-transform group-hover:translate-x-1" size={18} /></button>;
}

function TrustItem({ icon, title, body }: { icon: ReactNode; title: string; body: string }) {
  return <div className="flex gap-3"><div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#e9f3f7] text-[#276780]">{icon}</div><div><p className="text-sm font-bold">{title}</p><p className="mt-1 text-xs leading-5 text-[hsl(var(--muted-foreground))]">{body}</p></div></div>;
}

function MiniMetric({ label, value, tone }: { label: string; value: string; tone: 'good' | 'blue' }) {
  return <div className="rounded-lg bg-[#f5f8fa] p-3"><p className="text-[10px] font-semibold text-[hsl(var(--muted-foreground))]">{label}</p><p className={cx('mt-1 text-xs font-extrabold', tone === 'good' ? 'text-[#177a5e]' : 'text-[#2466a1]')}>{value}</p></div>;
}

function BrandWorkspace() {
  const [step, setStep] = usePersistentState('complainz-brand-step', 1);
  const [maxReached, setMaxReached] = usePersistentState('complainz-brand-max-step', step);
  const [selectedKey, setSelectedKey] = usePersistentState<CreatorKey>('complainz-selected-creator', 'wildcard');
  const [accepted, setAccepted] = usePersistentState('complainz-brand-accepted', false);
  const [mobileNav, setMobileNav] = useState(false);
  const [toast, setToast] = useState('');
  const [query, setQuery] = useState('');
  const [liveCreator, setLiveCreator] = useState<Creator | null>(null);
  const [campaign, setCampaign] = usePersistentState('complainz-campaign', { name: 'FW24 Street Edit', fee: '4800', start: '2024-10-14', end: '2024-11-02', usage: true, exclusivity: false, platforms: ['Instagram', 'TikTok'] });
  const liveLookup = useLookupOriane();
  const creator = selectedKey === 'live' && liveCreator ? liveCreator : creators[selectedKey === 'live' ? 'wildcard' : selectedKey];
  const notify = (message: string) => { setToast(message); window.setTimeout(() => setToast(''), 2500); };
  const go = (next: number) => {
    const destination = Math.max(1, Math.min(5, next));
    setStep(destination);
    if (destination > maxReached) setMaxReached(destination);
  };
  const navigate = (target: number) => {
    setMobileNav(false);
    if (target > maxReached) {
      go(Math.min(maxReached, target - 1));
      notify(`Complete the current step before opening ${['Choose creator', 'Find creator', 'Vetting report', 'Campaign setup', 'Contract'][target - 1]}.`);
    } else if (target >= 4 && !accepted) {
      go(3);
      notify('Select a creator in the vetting report before continuing.');
    } else {
      go(target);
    }
  };
  const stepContent = useMemo(() => ({ 1: 'Choose a creator', 2: 'Find a creator', 3: 'Read the decision brief', 4: 'Shape the campaign', 5: 'Make it signable' }[step]), [step]);
  const [emailOpen, setEmailOpen] = useState(false);
  useEffect(() => {
    if (selectedKey === 'live' && !liveCreator) {
      setSelectedKey('wildcard');
      setAccepted(false);
      setStep(2);
    }
  }, []);
  const lookupLiveCreator = (handle: string, platform: 'instagram' | 'tiktok') => {
    liveLookup.mutate(
      { data: { handle, platform } },
      {
        onSuccess: (data) => {
          const normalized = toLiveCreator(data);
          if (!normalized) {
            notify('Oriane returned no matching profile. Try the handle without the @.');
            return;
          }
          setLiveCreator(normalized);
          setSelectedKey('live');
          setAccepted(false);
          setStep(3);
          notify('Live Oriane profile loaded');
        },
        onError: (error) => notify(error instanceof Error ? error.message : 'Live Oriane lookup failed'),
      },
    );
  };
  return (
    <div className="app-shell flex min-h-[100dvh] flex-col">
      <Topbar mode="brand" title="Brand workspace" onMenu={() => setMobileNav(!mobileNav)} live={selectedKey === 'live' && Boolean(liveCreator)} />
      <div className="flex flex-1">
        <div className={cx('fixed inset-y-0 left-0 z-40 transition-transform md:static md:block md:translate-x-0', mobileNav ? 'translate-x-0' : '-translate-x-full')}><WorkspaceNav mode="brand" step={step} onNavigate={navigate} onClose={() => setMobileNav(false)} /></div>
        {mobileNav && <button type="button" aria-label="Close menu overlay" data-testid="button-close-menu-overlay" className="fixed inset-0 z-30 bg-[#15283a]/35 md:hidden" onClick={() => setMobileNav(false)} />}
        <main className="min-w-0 flex-1">
          <div className="mx-auto max-w-[1120px] px-4 py-7 sm:px-8 sm:py-10">
            <ProgressHeader step={step} total={5} mode="brand" />
            <div className="animate-rise" key={step}>
              <div className="mb-8 flex items-end justify-between gap-4"><div><h1 className="font-display text-3xl font-extrabold tracking-[-.04em] sm:text-4xl">{stepContent}</h1><p className="mt-2 max-w-xl text-sm leading-6 text-[hsl(var(--muted-foreground))]">{step === 1 ? 'Start with a clear brief. COMPLAINZ does the compliance work before your team does the outreach.' : step === 2 ? 'Search live Oriane data by handle, or select a seeded profile to keep the walkthrough moving.' : step === 3 ? 'A compact view of the evidence behind the score — not a mysterious green tick.' : step === 4 ? 'Put the commercial details in writing while the decision is fresh.' : creator.source === 'live' ? 'Live data does not verify permits or signing readiness.' : 'Review the guardrails, then create a signing-ready preview.'}</p></div><span className="hidden rounded-full border border-[#bdd8de] bg-[#edf8f8] px-3 py-1.5 text-[11px] font-bold text-[#166b77] sm:inline">{selectedKey === 'live' && liveCreator ? 'Live Oriane data' : 'Demo data · read-only sources'}</span></div>
              {step === 1 && <BrandStart onNext={() => go(2)} />}
               {step === 2 && <BrandLookup query={query} setQuery={setQuery} selectedKey={selectedKey} setSelectedKey={(key) => { setSelectedKey(key); setAccepted(false); }} onLiveLookup={lookupLiveCreator} isLiveLoading={liveLookup.isPending} onBack={() => go(1)} onNext={() => go(3)} />}
               {step === 3 && <BrandReportView creator={creator} selectedKey={selectedKey} setSelectedKey={(key) => { setSelectedKey(key); setAccepted(false); }} accepted={accepted} setAccepted={setAccepted} notify={notify} onBack={() => go(2)} onNext={() => go(4)} />}
              {step === 4 && <CampaignSetup campaign={campaign} setCampaign={setCampaign} creator={creator} onBack={() => go(3)} onNext={() => go(5)} />}
              {step === 5 && (creator.source === 'live'
                ? <div className="card max-w-2xl p-6 sm:p-8"><ShieldAlert size={25} className="text-[#a36a13]" /><h2 className="mt-4 font-display text-xl font-extrabold">Manual verification is required</h2><p className="mt-3 text-sm leading-6 text-[hsl(var(--muted-foreground))]">Oriane does not verify a creator permit, trade licence, or contractual identity in this lookup. The signing-ready document is available for the seeded demo only. Verify these details outside this preview before using a live creator in a contract.</p><button type="button" className="btn-secondary mt-6" onClick={() => go(4)}><ArrowLeft size={16} />Back to campaign</button></div>
                : <ContractStep creator={creator} campaign={campaign} accepted={accepted} onBack={() => go(4)} onEmail={() => setEmailOpen(true)} notify={notify} />)}
            </div>
          </div>
          <FooterNote />
        </main>
      </div>
      {emailOpen && <BrandEmailPreview onClose={() => setEmailOpen(false)} creatorHandle={creator.handle} campaign={campaign} />}
      {toast && <Toast text={toast} onClose={() => setToast('')} />}
    </div>
  );
}

function BrandStart({ onNext }: { onNext: () => void }) {
  const [selected, setSelected] = usePersistentState<string[]>('complainz-brand-categories', ['Fashion']);
  const [custom, setCustom] = useState<string[]>([]);
  const [adding, setAdding] = useState(false);
  const [newCategory, setNewCategory] = useState('');
  const choices = [...new Set(['Fashion', 'Alcohol', 'Financial services', 'Beauty', 'Technology', 'Travel', ...custom, ...selected])];
  const addCategory = () => {
    const name = newCategory.trim().slice(0, 40);
    if (!name) return;
    const existing = choices.find((choice) => choice.toLowerCase() === name.toLowerCase());
    if (!existing) setCustom([...custom, name]);
    setSelected([...new Set([...selected, existing || name])]);
    setNewCategory('');
    setAdding(false);
  };
  return <div className="grid gap-5 lg:grid-cols-[1.25fr_.75fr]">
    <div className="card overflow-hidden">
      <div className="border-b border-[hsl(var(--border))] bg-[#f7fafb] px-5 py-4"><div className="flex items-center gap-2 text-sm font-bold"><Store size={16} className="text-[hsl(var(--primary))]" />Your brand brief</div><p className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">Select the categories relevant to your campaign.</p></div>
      <div className="space-y-5 p-5 sm:p-7">
        <label className="block"><span className="mb-2 block text-xs font-bold">Brand or agency</span><input className="field" defaultValue="Northstar MENA" aria-label="Brand or agency" data-testid="input-brand-name" /></label>
        <label className="block"><span className="mb-2 block text-xs font-bold">What are you promoting?</span><input className="field" defaultValue="FW24 Street Edit" aria-label="Campaign name" data-testid="input-brand-campaign" /></label>
        <div><span className="mb-2 block text-xs font-bold">Potential categories to screen</span>
          <div className="flex flex-wrap gap-2">{choices.map((category) => <button key={category} type="button" aria-pressed={selected.includes(category)} onClick={() => setSelected(selected.includes(category) ? selected.filter((item) => item !== category) : [...selected, category])} className={cx('pill transition-colors', selected.includes(category) && '!border-[#66a7ba] !bg-[#e8f5f6] !text-[#176576]')} data-testid={`button-category-${category.toLowerCase().replaceAll(' ', '-')}`}>{selected.includes(category) && <Check size={12} />}{category}</button>)}<button type="button" className="pill border-dashed !text-[hsl(var(--primary))]" onClick={() => setAdding(true)} data-testid="button-add-category"><Plus size={12} />Add category</button></div>
          {adding && <div className="mt-3 flex gap-2"><input className="field" aria-label="New category" autoFocus maxLength={40} value={newCategory} onChange={(event) => setNewCategory(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') addCategory(); }} placeholder="Enter category" /><button type="button" className="btn-primary" disabled={!newCategory.trim()} onClick={addCategory}>Add</button><button type="button" className="btn-secondary" onClick={() => { setAdding(false); setNewCategory(''); }}>Cancel</button></div>}
          <p className="mt-2 text-xs text-[hsl(var(--muted-foreground))]">{selected.length ? `Selected: ${selected.join(', ')}` : 'Select at least one category to continue.'}</p>
        </div>
        <div className="flex justify-end border-t border-[hsl(var(--border))] pt-5"><button type="button" className="btn-primary disabled:opacity-50" disabled={!selected.length} onClick={onNext} data-testid="button-brand-brief-next">Choose a creator <ArrowRight size={16} /></button></div>
      </div>
    </div>
    <div className="card h-fit bg-[#eff7f7] p-5 sm:p-6"><div className="mb-5 flex h-10 w-10 items-center justify-center rounded-xl bg-white text-[#267b80]"><ShieldCheck size={20} /></div><h2 className="font-display text-xl font-extrabold tracking-tight">A cleaner first meeting</h2><p className="mt-2 text-sm leading-6 text-[#557177]">Choose relevant categories, then review creator evidence before outreach. This demo does not automatically verify category compliance.</p><div className="mt-6 space-y-3 text-xs font-semibold text-[#376269]"><p className="flex gap-2"><Check size={15} className="text-[#2d9876]" />Disclosure history</p><p className="flex gap-2"><Check size={15} className="text-[#2d9876]" />Restricted category conflicts</p><p className="flex gap-2"><Check size={15} className="text-[#2d9876]" />Permit and contract readiness</p></div></div>
  </div>;
}

function BrandLookup({ query, setQuery, selectedKey, setSelectedKey, onLiveLookup, isLiveLoading, onBack, onNext }: { query: string; setQuery: (v: string) => void; selectedKey: CreatorKey; setSelectedKey: (v: CreatorKey) => void; onLiveLookup: (handle: string, platform: 'instagram' | 'tiktok') => void; isLiveLoading: boolean; onBack: () => void; onNext: () => void }) {
  const [platform, setPlatform] = useState<'instagram' | 'tiktok'>('instagram');
  const result = Object.values(creators).filter((creator) => `${creator.handle} ${creator.name} ${creator.niche}`.toLowerCase().includes(query.toLowerCase()));
  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_330px]">
      <div className="card p-5 sm:p-7">
        <div className="relative"><Search size={17} className="absolute left-3 top-3.5 text-[hsl(var(--muted-foreground))]" /><input className="field pl-10" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search a live handle or seeded profile" aria-label="Search creators" data-testid="input-search-creators" /></div>
        <div className="mt-5 grid gap-3 sm:grid-cols-[1fr_auto] sm:items-end">
          <p className="text-xs font-bold text-[hsl(var(--muted-foreground))]">{result.length} seeded creators · or search Oriane live</p>
          <div className="flex items-center gap-2">
            <label className="sr-only" htmlFor="oriane-platform">Platform</label>
            <select id="oriane-platform" className="field !w-auto !py-2 text-xs" value={platform} onChange={(event) => setPlatform(event.target.value as 'instagram' | 'tiktok')} data-testid="select-oriane-platform">
              <option value="instagram">Instagram</option>
              <option value="tiktok">TikTok</option>
            </select>
            <button type="button" className="btn-secondary !px-3 !py-2 text-xs" disabled={!query.trim() || isLiveLoading} onClick={() => onLiveLookup(query, platform)} data-testid="button-live-lookup">
              {isLiveLoading ? <LoaderCircle size={14} className="animate-spin" /> : <Zap size={14} />}
              {isLiveLoading ? 'Checking…' : 'Check live'}
            </button>
          </div>
        </div>
        <div className="mt-3 space-y-3">{result.length ? result.map((creator) => <button type="button" key={creator.key} onClick={() => setSelectedKey(creator.key)} className={cx('flex w-full items-center justify-between rounded-xl border p-4 text-left transition', selectedKey === creator.key ? 'border-[hsl(var(--primary))] bg-[#f1f7fc] shadow-sm' : 'border-[hsl(var(--border))] hover:border-[#9bbec7]')} data-testid={`button-select-creator-${creator.key}`}><div className="flex items-center gap-3"><Avatar creator={creator} /><div><p className="text-sm font-bold">{creator.handle}</p><p className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">{creator.name} · {creator.niche}</p></div></div><div className="text-right"><p className="text-xs font-bold">{creator.followers}</p><p className="mt-1 text-[10px] text-[hsl(var(--muted-foreground))]">{creator.platform}</p></div></button>) : <EmptySearch />}</div>
        <div className="mt-6 flex justify-between border-t border-[hsl(var(--border))] pt-5"><button type="button" className="btn-secondary" onClick={onBack} data-testid="button-lookup-back"><ArrowLeft size={16} />Back</button><button type="button" className="btn-primary" onClick={onNext} data-testid="button-lookup-next">Open report <ArrowRight size={16} /></button></div>
      </div>
      <div className="card h-fit p-5"><p className="eyebrow">Oriane scope</p><h2 className="mt-2 font-display text-lg font-extrabold tracking-tight">Live evidence, with a seeded path for the walkthrough.</h2><p className="mt-2 text-xs leading-5 text-[hsl(var(--muted-foreground))]">Live checks search the server-side Oriane connection. The API key never reaches this browser.</p><div className="mt-5 space-y-2.5 text-xs font-semibold"><div className="flex items-center justify-between rounded-lg bg-[hsl(var(--muted))] px-3 py-2.5"><span className="text-[hsl(var(--muted-foreground))]">Platforms</span><span>Instagram + TikTok</span></div><div className="flex items-center justify-between rounded-lg bg-[hsl(var(--muted))] px-3 py-2.5"><span className="text-[hsl(var(--muted-foreground))]">Lookback</span><span>Last 3 months</span></div><div className="flex items-center justify-between rounded-lg bg-[hsl(var(--muted))] px-3 py-2.5"><span className="text-[hsl(var(--muted-foreground))]">Minimum</span><span>5K+ accounts</span></div></div></div>
    </div>
  );
}

function EmptySearch() {
  return <div className="rounded-xl border border-dashed border-[hsl(var(--border))] p-8 text-center"><Search className="mx-auto text-[hsl(var(--muted-foreground))]" size={22} /><p className="mt-3 text-sm font-bold">No seeded creator found</p><p className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">Enter a handle and use Check live to query Oriane.</p></div>;
}

function RiskBadge({ risk, tone }: { risk: number; tone: RiskTone }) {
  return <span className={cx('inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-extrabold', tone === 'low' ? 'bg-[#eaf7f1] text-[#187959]' : tone === 'medium' ? 'bg-[#fff6e5] text-[#9c6810]' : 'bg-[#fff0ed] text-[#a44338]')}><span className="text-sm">{risk}</span>/5 risk</span>;
}

function BrandReport({ creator, selectedKey, setSelectedKey, accepted, setAccepted, notify, onBack, onNext }: { creator: Creator; selectedKey: CreatorKey; setSelectedKey: (v: CreatorKey) => void; accepted: boolean; setAccepted: (v: boolean) => void; notify: (v: string) => void; onBack: () => void; onNext: () => void }) {
  const [open, setOpen] = useState<string | null>('disclosure');
  const isSara = selectedKey === 'sara';
  return <div className="space-y-5"><div className="grid gap-5 lg:grid-cols-[1.15fr_.85fr]"><div className="card p-5 sm:p-7"><div className="flex flex-wrap items-start justify-between gap-4"><div className="flex items-center gap-3"><Avatar creator={creator} /><div><p className="text-xl font-extrabold tracking-tight">{creator.handle}</p><p className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">{creator.name} · {creator.platform} · {creator.niche}</p></div></div><RiskBadge risk={creator.risk} tone={creator.riskTone} /></div><p className="mt-6 max-w-2xl text-sm leading-6 text-[hsl(var(--muted-foreground))]">{creator.summary}</p><div className="mt-6 grid grid-cols-3 gap-2"><Stat label="Followers" value={creator.followers} /><Stat label="Engagement" value={creator.engagement} /><Stat label="Past partners" value={isSara ? '11' : '7'} /></div></div><div className={cx('card p-5 sm:p-7', creator.riskTone === 'low' ? 'bg-[#eff8f4]' : 'bg-[#fff7ec]')}><div className="flex items-center justify-between"><div className={cx('flex h-10 w-10 items-center justify-center rounded-xl', creator.riskTone === 'low' ? 'bg-[#d6efe4] text-[#187959]' : 'bg-[#ffebc8] text-[#a36a13]')}>{creator.riskTone === 'low' ? <ShieldCheck size={21} /> : <ShieldAlert size={21} />}</div><span className="text-[11px] font-bold text-[hsl(var(--muted-foreground))]">Confidence {isSara ? 'High' : 'Needs review'}</span></div><h2 className="mt-5 font-display text-2xl font-extrabold tracking-tight">{isSara ? 'Safe to move forward' : 'Pause before outreach'}</h2><p className="mt-2 text-sm leading-6 text-[hsl(var(--muted-foreground))]">{isSara ? 'This profile clears the checks in your brief. Keep the disclosure and usage guardrails in the contract.' : 'There is enough upside to keep this in your shortlist, but not enough certainty to send a brief yet.'}</p>{isSara ? <button type="button" className={cx('mt-5 flex w-full items-center justify-center gap-2 rounded-lg py-3 text-sm font-bold', accepted ? 'bg-[#d8eee5] text-[#187959]' : 'bg-[#1a7d63] text-white')} onClick={() => { setAccepted(!accepted); notify(accepted ? 'Creator moved back to shortlist' : 'Creator accepted for campaign'); }} data-testid="button-accept-creator">{accepted ? <><CheckCircle2 size={16} />Accepted for campaign</> : <>Accept creator <Check size={16} /></>}</button> : <button type="button" className="mt-5 flex w-full items-center justify-center gap-2 rounded-lg border border-[#e0b565] bg-white/60 py-3 text-sm font-bold text-[#925f0d]" onClick={() => { setSelectedKey('sara'); notify('Showing the lower-risk creator'); }} data-testid="button-switch-safe-creator">Compare @sara.glow <ArrowRight size={16} /></button>}</div></div><div className="grid gap-5 lg:grid-cols-[1fr_.8fr]"><div className="card p-5 sm:p-7"><div className="flex items-start justify-between"><div><p className="eyebrow">Evidence across the brief</p><h2 className="mt-2 font-display text-xl font-extrabold tracking-tight">Risk factors</h2></div><span className="text-[11px] font-semibold text-[hsl(var(--muted-foreground))]">Last 3 months</span></div><div className="mt-5 divide-y divide-[hsl(var(--border))]">{riskFactors.map((factor) => <div key={factor.label} className="py-3.5 first:pt-0 last:pb-0"><button type="button" onClick={() => setOpen(open === factor.label ? null : factor.label)} className="flex w-full items-center justify-between text-left" data-testid={`button-expand-factor-${factor.label.replaceAll(' ', '-').toLowerCase()}`}><div className="flex items-center gap-3"><span className={cx('h-2 w-2 rounded-full', factor.tone === 'low' ? 'bg-[#45ad8c]' : factor.tone === 'medium' ? 'bg-[#dda233]' : 'bg-[#d06458]')} /><span className="text-sm font-bold">{factor.label}</span></div><ChevronDown size={16} className={cx('text-[hsl(var(--muted-foreground))] transition-transform', open === factor.label && 'rotate-180')} /></button>{open === factor.label && <div className="ml-5 mt-2 border-l border-[hsl(var(--border))] pl-4 text-xs leading-5 text-[hsl(var(--muted-foreground))]">{isSara ? factor.sara : factor.wild}</div>}</div>)}</div></div><CollaborationCard creator={creator} /></div><div className="card flex flex-wrap items-center justify-between gap-4 bg-[#f7fafb] p-4"><div className="flex items-start gap-3"><div className="mt-0.5 text-[#337a91]"><ShieldCheck size={17} /></div><div><p className="text-xs font-bold">Permit context</p><p className="mt-1 text-[11px] leading-5 text-[hsl(var(--muted-foreground))]">Creator permit: verified · Brand trade licence: verified · Source scope: demo only</p></div></div><div className="flex items-center gap-2"><button type="button" className="btn-secondary !px-3 !py-2 text-xs" onClick={onBack} data-testid="button-report-back"><ArrowLeft size={14} />Back</button><button type="button" className="btn-primary !px-3 !py-2 text-xs disabled:cursor-not-allowed disabled:opacity-50" disabled={!accepted} onClick={onNext} data-testid="button-report-next">Set up campaign <ArrowRight size={14} /></button></div></div></div>;
}

function BrandReportView({ creator, selectedKey, setSelectedKey, accepted, setAccepted, notify, onBack, onNext }: { creator: Creator; selectedKey: CreatorKey; setSelectedKey: (v: CreatorKey) => void; accepted: boolean; setAccepted: (v: boolean) => void; notify: (v: string) => void; onBack: () => void; onNext: () => void }) {
  const [open, setOpen] = useState<string | null>('disclosure');
  const isSara = selectedKey === 'sara';
  const canAccept = creator.riskTone !== 'high';
  const factors = creator.liveRiskFactors ?? riskFactors;
  return (
    <div className="space-y-5">
      <div className="grid gap-5 lg:grid-cols-[1.15fr_.85fr]">
        <div className="card p-5 sm:p-7">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="flex items-center gap-3"><Avatar creator={creator} /><div><p className="text-xl font-extrabold tracking-tight">{creator.handle}</p><p className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">{creator.name} · {creator.platform} · {creator.niche}</p></div></div>
            <div className="flex items-center gap-2"><span className={cx('rounded-full px-2.5 py-1 text-[10px] font-bold', creator.source === 'live' ? 'bg-[#eaf5fb] text-[#236d8c]' : 'bg-[#f3f5f6] text-[#687b85]')}>{creator.source === 'live' ? 'Live Oriane' : 'Seeded demo'}</span><RiskBadge risk={creator.risk} tone={creator.riskTone} /></div>
          </div>
          <p className="mt-6 max-w-2xl text-sm leading-6 text-[hsl(var(--muted-foreground))]">{creator.summary}</p>
          <div className="mt-6 grid grid-cols-3 gap-2"><Stat label="Followers" value={creator.followers} /><Stat label="Engagement" value={creator.engagement} /><Stat label="Past partners" value={creator.source === 'live' ? 'Unverified' : isSara ? '11' : '7'} /></div>
        </div>
        <div className={cx('card p-5 sm:p-7', canAccept ? 'bg-[#eff8f4]' : 'bg-[#fff7ec]')}>
          <div className="flex items-center justify-between"><div className={cx('flex h-10 w-10 items-center justify-center rounded-xl', canAccept ? 'bg-[#d6efe4] text-[#187959]' : 'bg-[#ffebc8] text-[#a36a13]')}>{canAccept ? <ShieldCheck size={21} /> : <ShieldAlert size={21} />}</div><span className="text-[11px] font-bold text-[hsl(var(--muted-foreground))]">Confidence {creator.source === 'live' ? 'Provisional' : canAccept ? 'High' : 'Needs review'}</span></div>
          <h2 className="mt-5 font-display text-2xl font-extrabold tracking-tight">{creator.source === 'live' ? canAccept ? 'Review the live signals' : 'More evidence needed' : canAccept ? 'Safe to move forward' : 'Pause before outreach'}</h2>
          <p className="mt-2 text-sm leading-6 text-[hsl(var(--muted-foreground))]">{creator.source === 'live' ? canAccept ? 'The returned content offers a starting point, not a compliance clearance. Verify permits, disclosures, and any commercial claims before outreach.' : 'The available sample is too limited or flagged. Do not treat this as a clearance; request more evidence.' : canAccept ? 'This profile clears the current checks. Keep the disclosure and usage guardrails in the contract.' : 'There is enough upside to keep this in your shortlist, but not enough certainty to send a brief yet.'}</p>
          {canAccept ? <button type="button" className={cx('mt-5 flex w-full items-center justify-center gap-2 rounded-lg py-3 text-sm font-bold', accepted ? 'bg-[#d8eee5] text-[#187959]' : 'bg-[#1a7d63] text-white')} onClick={() => { setAccepted(!accepted); notify(accepted ? 'Creator moved back to shortlist' : 'Creator selected for campaign review'); }} data-testid="button-accept-creator">{accepted ? <><CheckCircle2 size={16} />Selected for campaign review</> : <>Select for campaign review <Check size={16} /></>}</button> : <button type="button" className="mt-5 flex w-full items-center justify-center gap-2 rounded-lg border border-[#e0b565] bg-white/60 py-3 text-sm font-bold text-[#925f0d]" onClick={() => { setSelectedKey('sara'); notify('Showing the lower-risk creator'); }} data-testid="button-switch-safe-creator">Compare @sara.glow <ArrowRight size={16} /></button>}
        </div>
      </div>
      <div className="grid gap-5 lg:grid-cols-[1fr_.8fr]">
        <div className="card p-5 sm:p-7">
          <div className="flex items-start justify-between"><div><p className="eyebrow">Evidence across the brief</p><h2 className="mt-2 font-display text-xl font-extrabold tracking-tight">Risk factors</h2></div><span className="text-[11px] font-semibold text-[hsl(var(--muted-foreground))]">Last 3 months</span></div>
          <div className="mt-5 divide-y divide-[hsl(var(--border))]">{factors.map((factor) => <div key={factor.label} className="py-3.5 first:pt-0 last:pb-0"><button type="button" onClick={() => setOpen(open === factor.label ? null : factor.label)} className="flex w-full items-center justify-between text-left" data-testid={`button-expand-factor-${factor.label.replaceAll(' ', '-').toLowerCase()}`}><div className="flex items-center gap-3"><span className={cx('h-2 w-2 rounded-full', factor.tone === 'low' ? 'bg-[#45ad8c]' : factor.tone === 'medium' ? 'bg-[#dda233]' : 'bg-[#d06458]')} /><span className="text-sm font-bold">{factor.label}</span></div><ChevronDown size={16} className={cx('text-[hsl(var(--muted-foreground))] transition-transform', open === factor.label && 'rotate-180')} /></button>{open === factor.label && <div className="ml-5 mt-2 border-l border-[hsl(var(--border))] pl-4 text-xs leading-5 text-[hsl(var(--muted-foreground))]">{isSara ? factor.sara : factor.wild}</div>}</div>)}</div>
        </div>
        <CollaborationCard creator={creator} />
      </div>
      <div className="card flex flex-wrap items-center justify-between gap-4 bg-[#f7fafb] p-4"><div className="flex items-start gap-3"><div className="mt-0.5 text-[#337a91]"><ShieldCheck size={17} /></div><div><p className="text-xs font-bold">Permit context</p><p className="mt-1 text-[11px] leading-5 text-[hsl(var(--muted-foreground))]">Creator permit: verify with the creator · Brand trade licence: verify internally · Source scope: {creator.source === 'live' ? 'Oriane live lookup' : 'seeded demo'}</p></div></div><div className="flex items-center gap-2"><button type="button" className="btn-secondary !px-3 !py-2 text-xs" onClick={onBack} data-testid="button-report-back"><ArrowLeft size={14} />Back</button><button type="button" className="btn-primary !px-3 !py-2 text-xs disabled:cursor-not-allowed disabled:opacity-50" disabled={!accepted} onClick={onNext} data-testid="button-report-next">Set up campaign <ArrowRight size={14} /></button></div></div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) { return <div className="rounded-lg bg-[hsl(var(--muted))] p-3"><p className="text-[10px] font-semibold text-[hsl(var(--muted-foreground))]">{label}</p><p className="mt-1 text-sm font-extrabold">{value}</p></div>; }

function CollaborationCard({ creator }: { creator: Creator }) {
  if (creator.source === 'live') return <div className="card p-5 sm:p-7"><p className="eyebrow">Past collaborations</p><h2 className="mt-2 font-display text-xl font-extrabold tracking-tight">Not verified in this lookup</h2><p className="mt-4 text-sm leading-6 text-[hsl(var(--muted-foreground))]">Oriane’s returned posts do not confirm past brand partnerships. Ask the creator for a portfolio and reference contacts before making a decision.</p></div>;
  return <div className="card p-5 sm:p-7"><p className="eyebrow">Past collaborations</p><h2 className="mt-2 font-display text-xl font-extrabold tracking-tight">A track record you can read</h2><div className="mt-5 space-y-3"><CollabRow brand="Maison Noura" tier="Tier A" status="On brief" creator={creator} /><CollabRow brand="Solis Studio" tier="Tier B" status={creator.key === 'sara' ? 'Repeat partner' : 'Review needed'} creator={creator} /><CollabRow brand="The Edit DXB" tier="Tier B" status="Delivered" creator={creator} /></div></div>;
}

function CollabRow({ brand, tier, status, creator }: { brand: string; tier: string; status: string; creator: Creator }) {
  return <div className="flex items-center justify-between gap-3 rounded-lg border border-[hsl(var(--border))] p-3"><div className="flex items-center gap-2.5"><div className="flex h-7 w-7 items-center justify-center rounded bg-[#eef2f4] text-[10px] font-extrabold text-[#5d7480]">{brand.slice(0, 2).toUpperCase()}</div><div><p className="text-xs font-bold">{brand}</p><p className="mt-0.5 text-[10px] text-[hsl(var(--muted-foreground))]">{tier}</p></div></div><span className={cx('text-[10px] font-bold', status === 'Review needed' ? 'text-[#a46e14]' : 'text-[#197b62]')}>{status}</span></div>;
}

function CampaignSetup({ campaign, setCampaign, creator, onBack, onNext }: { campaign: { name: string; fee: string; start: string; end: string; usage: boolean; exclusivity: boolean; platforms: string[] }; setCampaign: (v: { name: string; fee: string; start: string; end: string; usage: boolean; exclusivity: boolean; platforms: string[] }) => void; creator: Creator; onBack: () => void; onNext: () => void }) {
  const update = (partial: Partial<typeof campaign>) => setCampaign({ ...campaign, ...partial });
  const togglePlatform = (platform: string) => update({ platforms: campaign.platforms.includes(platform) ? campaign.platforms.filter((item) => item !== platform) : [...campaign.platforms, platform] });
  return <div className="grid gap-5 lg:grid-cols-[1fr_350px]"><div className="card p-5 sm:p-7"><div className="grid gap-5 sm:grid-cols-2"><label className="block sm:col-span-2"><span className="mb-2 block text-xs font-bold">Campaign name</span><input className="field" value={campaign.name} onChange={(event) => update({ name: event.target.value })} aria-label="Campaign name" data-testid="input-campaign-name" /></label><label className="block"><span className="mb-2 block text-xs font-bold">Start date</span><div className="relative"><CalendarDays size={16} className="absolute right-3 top-3.5 text-[hsl(var(--muted-foreground))]" /><input type="date" className="field" value={campaign.start} onChange={(event) => update({ start: event.target.value })} aria-label="Campaign start date" data-testid="input-campaign-start" /></div></label><label className="block"><span className="mb-2 block text-xs font-bold">End date</span><div className="relative"><CalendarDays size={16} className="absolute right-3 top-3.5 text-[hsl(var(--muted-foreground))]" /><input type="date" className="field" value={campaign.end} onChange={(event) => update({ end: event.target.value })} aria-label="Campaign end date" data-testid="input-campaign-end" /></div></label><label className="block sm:col-span-2"><span className="mb-2 block text-xs font-bold">Creator fee (AED)</span><input type="number" className="field" value={campaign.fee} onChange={(event) => update({ fee: event.target.value })} aria-label="Creator fee" data-testid="input-campaign-fee" /></label></div><div className="mt-7 border-t border-[hsl(var(--border))] pt-6"><span className="mb-3 block text-xs font-bold">Deliverable platforms</span><div className="flex flex-wrap gap-2">{['Instagram', 'TikTok'].map((platform) => <button type="button" key={platform} onClick={() => togglePlatform(platform)} className={cx('flex items-center gap-2 rounded-lg border px-3 py-2 text-xs font-bold', campaign.platforms.includes(platform) ? 'border-[#86b4c4] bg-[#edf7f8] text-[#1b6270]' : 'border-[hsl(var(--border))] text-[hsl(var(--muted-foreground))]')} data-testid={`button-platform-${platform.toLowerCase()}`}>{campaign.platforms.includes(platform) ? <Check size={14} /> : <Plus size={14} />}{platform}</button>)}</div></div><div className="mt-7 border-t border-[hsl(var(--border))] pt-6"><span className="mb-3 block text-xs font-bold">Rights and guardrails</span><ToggleRow label="Paid usage rights" description="Brand can use approved deliverables for the campaign." value={campaign.usage} onChange={() => update({ usage: !campaign.usage })} testId="toggle-usage-rights" /><ToggleRow label="Named competitor exclusivity" description="Block direct competitors during the campaign window." value={campaign.exclusivity} onChange={() => update({ exclusivity: !campaign.exclusivity })} testId="toggle-exclusivity" /></div><div className="mt-7 flex justify-between border-t border-[hsl(var(--border))] pt-5"><button type="button" className="btn-secondary" onClick={onBack} data-testid="button-campaign-back"><ArrowLeft size={16} />Back</button><button type="button" className="btn-primary" onClick={onNext} data-testid="button-campaign-next">Review contract <ArrowRight size={16} /></button></div></div><div className="card h-fit bg-[#f3f7fb] p-5 sm:p-6"><p className="eyebrow">Commercial snapshot</p><div className="mt-5 flex items-center gap-3"><Avatar creator={creator} small /><div><p className="text-sm font-extrabold">{creator.handle}</p><p className="text-xs text-[hsl(var(--muted-foreground))]">{creator.platform} · selected creator</p></div></div><div className="mt-6 space-y-3 border-t border-[#dce5ec] pt-5 text-xs"><SummaryLine label="Fee" value={`AED ${Number(campaign.fee || 0).toLocaleString()}`} /><SummaryLine label="Platforms" value={campaign.platforms.join(' + ') || 'None selected'} /><SummaryLine label="Rights" value={campaign.usage ? 'Campaign usage' : 'Organic only'} /><SummaryLine label="Exclusivity" value={campaign.exclusivity ? 'On' : 'Off'} /></div></div></div>;
}

function ToggleRow({ label, description, value, onChange, testId }: { label: string; description: string; value: boolean; onChange: () => void; testId: string }) {
  return <button type="button" onClick={onChange} className="flex w-full items-center justify-between gap-4 border-b border-[hsl(var(--border))] py-3 text-left last:border-0" data-testid={testId}><span><span className="block text-xs font-bold">{label}</span><span className="mt-1 block text-[11px] leading-4 text-[hsl(var(--muted-foreground))]">{description}</span></span>{value ? <ToggleRight size={30} className="shrink-0 text-[hsl(var(--primary))]" /> : <ToggleLeft size={30} className="shrink-0 text-[hsl(var(--muted-foreground))]" />}</button>;
}

function SummaryLine({ label, value }: { label: string; value: string }) { return <div className="flex items-center justify-between gap-3"><span className="text-[hsl(var(--muted-foreground))]">{label}</span><span className="text-right font-bold">{value}</span></div>; }

function ContractStep({ creator, campaign, accepted, onBack, onEmail, notify }: { creator: Creator; campaign: { name: string; fee: string; start: string; end: string; usage: boolean; exclusivity: boolean; platforms: string[] }; accepted: boolean; onBack: () => void; onEmail: () => void; notify: (v: string) => void }) {
  const [, setLocation] = useLocation();
  const [checked, setChecked] = useState(true);
  const [preview, setPreview] = useState(false);
  const copySummary = async () => {
    const summary = [
      `${campaign.name} — creator agreement draft`,
      `Creator: ${creator.name} (${creator.handle})`,
      `Fee: AED ${Number(campaign.fee).toLocaleString()}`,
      `Dates: ${campaign.start} to ${campaign.end}`,
      `Platforms: ${campaign.platforms.join(', ') || 'Not selected'}`,
      `Usage: ${campaign.usage ? 'Campaign channels and dates only' : 'Creator organic channels only'}`,
      `Exclusivity: ${campaign.exclusivity ? 'Named competitors during campaign' : 'None'}`,
      'Status: Demo draft; verify permits and terms before signing.',
    ].join('\n');
    try {
      await navigator.clipboard.writeText(summary);
      notify('Campaign summary copied to clipboard.');
    } catch {
      notify('Clipboard access is unavailable. Please copy the details from Preview.');
    }
  };
  return <div className="grid gap-5 lg:grid-cols-[1fr_340px]">
    <div className="card p-5 sm:p-7">
      <div className="flex items-start justify-between gap-3"><div><p className="eyebrow">Contract guardrails</p><h2 className="mt-2 font-display text-xl font-extrabold tracking-tight">A brief both sides can sign</h2><p className="mt-2 text-sm leading-6 text-[hsl(var(--muted-foreground))]">Review the protections and commercial details before continuing.</p></div><FileCheck2 className="text-[hsl(var(--primary))]" size={23} /></div>
      <div className="mt-6 space-y-2.5"><ContractCheck label="Disclosure on every sponsored deliverable" /><ContractCheck label={`Usage limited to ${campaign.usage ? 'campaign channels and dates' : 'creator organic channels'}`} /><ContractCheck label={campaign.exclusivity ? 'Named competitor exclusivity' : 'No competitor exclusivity'} /><ContractCheck label="Payment due within 15 business days of approval" /></div>
      <label className="mt-6 flex gap-3 rounded-lg bg-[#f3f8fa] p-3.5 text-xs leading-5"><input type="checkbox" checked={checked} onChange={(event) => setChecked(event.target.checked)} className="mt-1 accent-[#1f6fa6]" data-testid="checkbox-contract-review" /><span>I’ve reviewed the compliance checklist and commercial summary. I understand this demo is not legal advice.</span></label>
      <div className="mt-6 flex flex-wrap justify-between gap-3 border-t border-[hsl(var(--border))] pt-5"><button type="button" className="btn-secondary" onClick={onBack} data-testid="button-contract-back"><ArrowLeft size={16} />Back</button><div className="flex flex-wrap gap-2"><button type="button" className="btn-secondary" onClick={() => setPreview(true)} data-testid="button-preview-contract"><FileText size={15} />Preview</button><button type="button" className="btn-primary disabled:opacity-50" disabled={!checked || !accepted} onClick={() => setLocation('/sign/demo-fw24')} data-testid="button-send-contract">Create signing link <Link2 size={15} /></button></div></div>
    </div>
    <div className="card h-fit p-5 sm:p-6">
      <p className="eyebrow">Ready to move</p>
      <div className="mt-5 flex items-center gap-3"><Avatar creator={creator} small /><div><p className="text-sm font-extrabold">{creator.handle}</p><p className="text-xs text-[hsl(var(--muted-foreground))]">Permit requires independent verification</p></div></div>
      <div className="mt-5 rounded-lg bg-[#eaf7f1] p-3.5"><p className="text-xs font-bold text-[#187959]">Contract status</p><p className="mt-1 text-sm font-extrabold text-[#155f4a]">Demo draft ready for review</p></div>
      <div className="mt-4 space-y-2">
        <button type="button" className="flex w-full items-center justify-between rounded-lg border border-[hsl(var(--border))] px-3 py-2.5 text-xs font-bold" onClick={copySummary} data-testid="button-copy-contract"><span className="flex items-center gap-2"><Copy size={14} />Copy summary</span><ChevronRight size={14} /></button>
        <button type="button" className="flex w-full items-center justify-between rounded-lg border border-[hsl(var(--border))] px-3 py-2.5 text-xs font-bold" onClick={onEmail} data-testid="button-email-contract"><span className="flex items-center gap-2"><Mail size={14} />Preview email</span><ChevronRight size={14} /></button>
      </div>
    </div>
    {preview && <ContractPreview creator={creator} campaign={campaign} onClose={() => setPreview(false)} />}
  </div>;
}

function ContractCheck({ label }: { label: string }) { return <div className="flex items-center gap-3 rounded-lg border border-[hsl(var(--border))] px-3.5 py-3 text-sm font-semibold"><span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#e4f4ed] text-[#18805f]"><Check size={13} /></span>{label}</div>; }

function ContractPreview({ creator, campaign, onClose }: { creator: Creator; campaign: { name: string; fee: string; start: string; end: string; usage: boolean; exclusivity: boolean; platforms: string[] }; onClose: () => void }) {
  return <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#122438]/45 p-4"><div className="max-h-[90vh] w-full max-w-2xl overflow-auto rounded-2xl bg-white p-5 shadow-2xl sm:p-8"><div className="flex items-start justify-between border-b border-[hsl(var(--border))] pb-5"><div><Wordmark compact /><p className="mt-3 text-xs text-[hsl(var(--muted-foreground))]">Signing preview · generated in demo mode</p></div><button type="button" onClick={onClose} className="rounded-lg p-2 hover:bg-[hsl(var(--muted))]" aria-label="Close contract preview" data-testid="button-close-contract-preview"><X size={18} /></button></div><div className="py-6"><p className="eyebrow">Creator agreement</p><h2 className="mt-2 font-display text-2xl font-extrabold">{campaign.name}</h2><p className="mt-2 text-sm text-[hsl(var(--muted-foreground))]">Northstar MENA × {creator.handle}</p><div className="mt-6 grid gap-3 sm:grid-cols-2"><SummaryLine label="Fee" value={`AED ${Number(campaign.fee).toLocaleString()}`} /><SummaryLine label="Period" value={`${campaign.start} → ${campaign.end}`} /><SummaryLine label="Platforms" value={campaign.platforms.join(', ')} /><SummaryLine label="Signature status" value="Awaiting creator" /></div><div className="mt-7 space-y-4 border-t border-[hsl(var(--border))] pt-5 text-sm leading-6"><p><strong>Deliverables.</strong> Creator will produce and publish the agreed content on the selected platforms, with paid partnership disclosure visible on each sponsored deliverable.</p><p><strong>Rights.</strong> Approved content may be used by Northstar MENA for the named campaign period and channels only.</p><p><strong>Payment.</strong> AED {Number(campaign.fee).toLocaleString()} payable within 15 business days of first approved deliverable.</p></div></div><button type="button" className="btn-primary w-full" onClick={onClose} data-testid="button-close-preview">Back to contract</button></div></div>;
}

function CreatorWorkspace() {
  const [step, setStep] = usePersistentState('complainz-creator-step', 1);
  const [, setLocation] = useLocation();
  const [analysis, setAnalysis] = useState<ContractAnalysis | null>(null);
  const [accepted, setAccepted] = useState<string[]>([]);
  const [mobileNav, setMobileNav] = useState(false);
  const [toast, setToast] = useState('');
  const notify = (message: string) => { setToast(message); window.setTimeout(() => setToast(''), 3000); };
  const navigate = (target: number) => {
    setMobileNav(false);
    if (target === 2 && !analysis) {
      setStep(1);
      notify('Upload and analyze a PDF to open its findings.');
    } else {
      setStep(target);
    }
  };
  useEffect(() => {
    if (step !== 1 && !analysis) setStep(1);
  }, [step, analysis, setStep]);
  return <div className="app-shell flex min-h-[100dvh] flex-col">
    <Topbar mode="creator" title="Creator workspace" onMenu={() => setMobileNav(!mobileNav)} live={Boolean(analysis)} />
    <div className="flex flex-1">
      <div className={cx('fixed inset-y-0 left-0 z-40 md:static md:block md:self-stretch md:translate-x-0', mobileNav ? 'translate-x-0' : '-translate-x-full')}><WorkspaceNav mode="creator" step={step} onNavigate={navigate} onClose={() => setMobileNav(false)} /></div>
      {mobileNav && <button type="button" aria-label="Close menu overlay" data-testid="button-close-creator-menu-overlay" className="fixed inset-0 z-30 bg-[#15283a]/35 md:hidden" onClick={() => setMobileNav(false)} />}
      <main className="min-w-0 flex-1"><div className="mx-auto max-w-[1120px] px-4 py-7 sm:px-8 sm:py-10">
        <ProgressHeader step={step} total={2} mode="creator" />
        <div className="animate-rise" key={step}>
          {step === 1 && <CreatorPdfUpload onBack={() => setLocation('/')} onAnalyzed={(result) => { setAnalysis(result); setAccepted(result.findings.map((finding) => finding.id)); setStep(2); }} />}
          {step === 2 && analysis && <CreatorPdfAnalysis analysis={analysis} accepted={accepted} setAccepted={setAccepted} onBack={() => setStep(1)} />}
        </div>
      </div><FooterNote /></main>
    </div>
    {toast && <Toast text={toast} onClose={() => setToast('')} />}
  </div>;
}

function CreatorAccount({ onNext }: { onNext: () => void }) {
  return <div className="grid gap-5 lg:grid-cols-[1fr_330px]"><div className="card p-5 sm:p-7"><div className="flex items-center gap-3 border-b border-[hsl(var(--border))] pb-5"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#eaf4f8] text-[#286d87]"><UserRound size={20} /></div><div><p className="text-sm font-extrabold">Tell us who you are</p><p className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">This helps us read a contract in your context.</p></div></div><div className="mt-6 grid gap-5 sm:grid-cols-2"><label><span className="mb-2 block text-xs font-bold">Full name</span><input className="field" defaultValue="Maya Rahman" aria-label="Full name" data-testid="input-creator-name" /></label><label><span className="mb-2 block text-xs font-bold">Creator handle</span><input className="field" defaultValue="@mayamakes" aria-label="Creator handle" data-testid="input-creator-handle" /></label><label><span className="mb-2 block text-xs font-bold">Primary platform</span><select className="field" defaultValue="Instagram" aria-label="Primary platform" data-testid="select-creator-platform"><option>Instagram</option><option>TikTok</option></select></label><label><span className="mb-2 block text-xs font-bold">Audience size</span><select className="field" defaultValue="25K–50K" aria-label="Audience size" data-testid="select-audience-size"><option>5K–25K</option><option>25K–50K</option><option>50K+</option></select></label></div><div className="mt-7 flex justify-end border-t border-[hsl(var(--border))] pt-5"><button type="button" className="btn-primary" onClick={onNext} data-testid="button-creator-account-next">Continue <ArrowRight size={16} /></button></div></div><div className="card h-fit bg-[#f3f8f7] p-5 sm:p-6"><p className="eyebrow !text-[#267d68]">Private by design</p><h2 className="mt-2 font-display text-xl font-extrabold tracking-tight">You decide what moves forward.</h2><p className="mt-2 text-sm leading-6 text-[#5a7773]">This demo keeps your contract analysis on this device. Nothing is sent to a client or platform.</p><div className="mt-6 flex items-center gap-2 text-xs font-bold text-[#36746a]"><ShieldCheck size={16} />Client-ready clarity</div></div></div>;
}

function CreatorUpload({ onBack, onNext }: { onBack: () => void; onNext: () => void }) {
  const [uploaded, setUploaded] = useState(false);
  return <div className="grid gap-5 lg:grid-cols-[1fr_330px]"><div className="card p-5 sm:p-7"><div className="border-b border-[hsl(var(--border))] pb-5"><p className="eyebrow">Contract input</p><h2 className="mt-2 font-display text-2xl font-extrabold tracking-tight">Upload a contract, or use our sample</h2><p className="mt-2 text-sm leading-6 text-[hsl(var(--muted-foreground))]">We’ll extract terms, highlight creator-unfriendly clauses, and explain what to ask for.</p></div><button type="button" onClick={() => setUploaded(true)} className={cx('mt-6 flex w-full flex-col items-center justify-center rounded-xl border-2 border-dashed p-10 text-center transition', uploaded ? 'border-[#7dbfa8] bg-[#eef8f3]' : 'border-[#b9ced4] bg-[#f8fbfc] hover:border-[#6cabb9]')} data-testid="button-upload-contract"><div className={cx('flex h-11 w-11 items-center justify-center rounded-xl', uploaded ? 'bg-[#d5eee2] text-[#187959]' : 'bg-[#e4f0f4] text-[#286d87]')}>{uploaded ? <CheckCircle2 size={22} /> : <CloudUpload size={22} />}</div><p className="mt-4 text-sm font-extrabold">{uploaded ? 'Sample contract loaded' : 'Drop a PDF here'}</p><p className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">{uploaded ? 'unfair_brand_contract.pdf · 248 KB' : 'or click to load the deliberately unfair demo contract'}</p></button><div className="mt-5 flex items-start gap-3 rounded-lg bg-[#fff8ec] p-3.5 text-xs leading-5 text-[#80611f]"><Sparkles size={15} className="mt-0.5 shrink-0" />The sample is intentionally uneven so you can see COMPLAINZ explain the leverage, not just flag it.</div><div className="mt-6 flex justify-between border-t border-[hsl(var(--border))] pt-5"><button type="button" className="btn-secondary" onClick={onBack} data-testid="button-upload-back"><ArrowLeft size={16} />Back</button><button type="button" className="btn-primary" onClick={onNext} data-testid="button-upload-analyze">Analyze contract <Sparkles size={15} /></button></div></div><div className="card h-fit p-5 sm:p-6"><p className="eyebrow">What you’ll get</p><div className="mt-5 space-y-4"><FeatureLine icon={<FileText size={15} />} title="Terms extracted" body="Fee, usage, exclusivity, timing" /><FeatureLine icon={<ShieldAlert size={15} />} title="Risk explained" body="Quoted text with plain-language context" /><FeatureLine icon={<MessageSquareText size={15} />} title="Requested changes" body="A practical, copyable response" /></div></div></div>;
}

function FeatureLine({ icon, title, body }: { icon: ReactNode; title: string; body: string }) { return <div className="flex gap-3"><div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#eef4f7] text-[#36728b]">{icon}</div><div><p className="text-xs font-bold">{title}</p><p className="mt-1 text-[11px] text-[hsl(var(--muted-foreground))]">{body}</p></div></div>; }

function CreatorAnalysis({ accepted, setAccepted, notify, onBack, onEmail }: { accepted: string[]; setAccepted: (v: string[]) => void; notify: (v: string) => void; onBack: () => void; onEmail: () => void }) {
  const [open, setOpen] = useState<string | null>('disclosure');
  const toggleAccepted = (id: string) => setAccepted(accepted.includes(id) ? accepted.filter((item) => item !== id) : [...accepted, id]);
  return <div className="space-y-5"><div className="grid gap-5 lg:grid-cols-[1fr_330px]"><div className="card p-5 sm:p-7"><div className="flex items-start justify-between gap-4"><div><p className="eyebrow">Contract analysis</p><h2 className="mt-2 font-display text-2xl font-extrabold tracking-tight">Unfair terms, made legible</h2><p className="mt-2 text-sm leading-6 text-[hsl(var(--muted-foreground))]">unfair_brand_contract.pdf · analyzed just now</p></div><span className="rounded-full bg-[#fff0ed] px-2.5 py-1 text-[11px] font-extrabold text-[#a44338]">3 changes suggested</span></div><div className="mt-6 space-y-2.5">{contractFindings.map((finding) => <div key={finding.id} className="rounded-xl border border-[hsl(var(--border))]"><button type="button" onClick={() => setOpen(open === finding.id ? null : finding.id)} className="flex w-full items-center justify-between gap-3 p-4 text-left" data-testid={`button-expand-finding-${finding.id}`}><div className="flex items-start gap-3"><span className={cx('mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full', finding.status === 'Fix needed' ? 'bg-[#fff0ed] text-[#b44b3e]' : 'bg-[#fff6e5] text-[#a46c14]')}><ShieldAlert size={12} /></span><span><span className="block text-sm font-bold">{finding.title}</span><span className="mt-1 block text-[10px] font-bold uppercase tracking-wide text-[hsl(var(--muted-foreground))]">{finding.status}</span></span></div><ChevronDown size={16} className={cx('shrink-0 text-[hsl(var(--muted-foreground))] transition-transform', open === finding.id && 'rotate-180')} /></button>{open === finding.id && <div className="border-t border-[hsl(var(--border))] px-4 pb-4 pt-3"><blockquote className="border-l-2 border-[#d5a13b] pl-3 text-xs italic leading-5 text-[#6f5b33]">“{finding.quote}”</blockquote><p className="mt-3 text-xs leading-5 text-[hsl(var(--muted-foreground))]">{finding.explanation}</p><div className="mt-3 rounded-lg bg-[#f2f8fa] p-3 text-xs leading-5"><span className="font-bold text-[#296b82]">Suggested fix: </span>{finding.fix}</div><button type="button" onClick={() => { toggleAccepted(finding.id); notify(accepted.includes(finding.id) ? 'Change removed from response' : 'Change accepted for response'); }} className={cx('mt-3 flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-bold', accepted.includes(finding.id) ? 'bg-[#e4f4ed] text-[#187959]' : 'border border-[hsl(var(--border))] text-[hsl(var(--foreground))]')} data-testid={`button-accept-finding-${finding.id}`}>{accepted.includes(finding.id) ? <CheckCircle2 size={14} /> : <Check size={14} />}{accepted.includes(finding.id) ? 'Accepted change' : 'Accept requested change'}</button></div>}</div>)}</div></div><CompensationCard /></div><div className="grid gap-5 lg:grid-cols-[1fr_.8fr]"><div className="card bg-[#eff7f4] p-5 sm:p-7"><div className="flex items-center gap-2"><BadgeCheck className="text-[#1b7b5e]" size={19} /><p className="eyebrow !text-[#21795f]">Your verdict</p></div><h2 className="mt-3 font-display text-2xl font-extrabold tracking-tight">Don’t sign as-is.</h2><p className="mt-2 max-w-xl text-sm leading-6 text-[#4f716b]">The opportunity looks workable once the usage, exclusivity, and disclosure clauses are narrowed. Ask for the changes before you accept the fee.</p><div className="mt-5 flex flex-wrap gap-2"><span className="pill !border-[#b6d9cc] !bg-white !text-[#21795f]">{accepted.length} changes accepted</span><span className="pill !border-[#b6d9cc] !bg-white !text-[#21795f]">Fair range: AED 4.2K–5.8K</span></div></div><div className="card p-5 sm:p-7"><p className="eyebrow">Next move</p><h2 className="mt-2 font-display text-xl font-extrabold tracking-tight">Send a clear response</h2><p className="mt-2 text-xs leading-5 text-[hsl(var(--muted-foreground))]">Your accepted changes can become a polite, specific email instead of a vague negotiation.</p><button type="button" className="btn-primary mt-5 w-full" onClick={onEmail} data-testid="button-preview-response"><Mail size={15} />Preview response email</button><button type="button" className="btn-secondary mt-2 w-full" onClick={() => notify('Requested changes copied')} data-testid="button-copy-changes"><ClipboardCopy size={15} />Copy requested changes</button></div></div><div className="flex justify-between gap-3"><button type="button" className="btn-secondary" onClick={onBack} data-testid="button-analysis-back"><ArrowLeft size={16} />Back</button><span className="flex items-center gap-1.5 text-[11px] text-[hsl(var(--muted-foreground))]"><ShieldCheck size={14} className="text-[#238366]" />Private demo analysis</span></div></div>;
}

function CompensationCard() {
  return <div className="card p-5 sm:p-7"><div className="flex items-start justify-between"><div><p className="eyebrow">Compensation check</p><h2 className="mt-2 font-display text-xl font-extrabold tracking-tight">The number needs context</h2></div><div className="flex h-12 w-12 items-center justify-center rounded-full border-[4px] border-[#dfa84b] text-lg font-extrabold text-[#a16b12]">C<span className="text-[9px]">+</span></div></div><div className="mt-5 rounded-xl bg-[#fff8eb] p-4"><div className="flex items-center justify-between text-xs"><span className="font-bold text-[#80611f]">Offered</span><span className="font-extrabold text-[#80611f]">AED 3,500</span></div><div className="mt-3 h-2 rounded-full bg-[#f2dfb8]"><div className="h-2 w-[45%] rounded-full bg-[#dca340]" /></div><div className="mt-3 flex items-center justify-between text-[10px] font-semibold text-[#92733c]"><span>Fair range</span><span>AED 4,200 – 5,800</span></div></div><p className="mt-4 text-xs leading-5 text-[hsl(var(--muted-foreground))]">The fee is below the fair range once 24-month exclusivity and perpetual usage are included. Narrow the rights or bring the fee up.</p></div>;
}

function SignaturePage() {
  const [, setLocation] = useLocation();
  const [signed, setSigned] = usePersistentState('complainz-signed-demo-fw24', false);
  const [name, setName] = useState('');
  const [agree, setAgree] = useState(false);
  const [emailOpen, setEmailOpen] = useState(false);
  const canSign = name.trim().length > 2 && agree;
  return <div className="app-shell flex min-h-[100dvh] flex-col"><header className="flex items-center justify-between border-b border-[hsl(var(--border))] bg-white px-5 py-5 sm:px-10"><Link href="/" className="flex items-center" data-testid="link-signature-home"><Wordmark compact /></Link><span className="flex items-center gap-1.5 text-[11px] font-bold text-[#197b62]"><ShieldCheck size={15} />Secure demo signing room</span></header><main className="section-wrap flex flex-1 flex-col py-8 sm:py-14"><div className="mx-auto w-full max-w-3xl"><div className="mb-8 text-center"><p className="eyebrow">Northstar MENA · creator agreement</p><h1 className="mt-3 font-display text-3xl font-extrabold tracking-[-.04em] sm:text-5xl">{signed ? 'Agreement signed.' : 'Review before you sign.'}</h1><p className="mx-auto mt-3 max-w-xl text-sm leading-6 text-[hsl(var(--muted-foreground))]">{signed ? 'A copy of this demo agreement is ready to download or share.' : 'One last, calm look at the commercial terms. No account required.'}</p></div>{signed ? <SignedState onHome={() => setLocation('/')} onEmail={() => setEmailOpen(true)} /> : <div className="grid gap-5 lg:grid-cols-[1fr_310px]"><div className="card p-5 sm:p-8"><div className="flex items-start justify-between border-b border-[hsl(var(--border))] pb-5"><div><p className="text-lg font-extrabold">FW24 Street Edit</p><p className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">Northstar MENA × @sara.glow</p></div><span className="rounded-full bg-[#fff7e8] px-2.5 py-1 text-[10px] font-bold text-[#9b6b17]">Awaiting signature</span></div><div className="grid gap-4 border-b border-[hsl(var(--border))] py-6 sm:grid-cols-2"><SummaryLine label="Creator fee" value="AED 4,800" /><SummaryLine label="Campaign dates" value="14 Oct – 02 Nov 2024" /><SummaryLine label="Platforms" value="Instagram + TikTok" /><SummaryLine label="Usage" value="Campaign only" /></div><div className="space-y-4 py-6 text-sm leading-6"><p><strong>Deliverables.</strong> Agreed content will be published with visible paid partnership disclosure on each sponsored deliverable.</p><p><strong>Payment.</strong> AED 4,800 due within 15 business days of the first approved deliverable.</p><p><strong>Rights.</strong> Approved content may be used for the named campaign, on the selected platforms, during the campaign dates.</p></div><div className="border-t border-[hsl(var(--border))] pt-5"><label className="block"><span className="mb-2 block text-xs font-bold">Type your full name to sign</span><input className="field" value={name} onChange={(event) => setName(event.target.value)} placeholder="Maya Rahman" aria-label="Signature name" data-testid="input-signature-name" /></label><label className="mt-4 flex gap-3 text-xs leading-5 text-[hsl(var(--muted-foreground))]"><input type="checkbox" checked={agree} onChange={(event) => setAgree(event.target.checked)} className="mt-1 accent-[#1f6fa6]" data-testid="checkbox-signature-agreement" /><span>I confirm I have read this agreement and agree to sign it electronically.</span></label><button type="button" disabled={!canSign} onClick={() => setSigned(true)} className="btn-primary mt-5 w-full disabled:cursor-not-allowed disabled:opacity-45" data-testid="button-complete-signature"><PenLine size={16} />Complete signature</button></div></div><div className="card h-fit bg-[#f3f8f7] p-5 sm:p-6"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#d9eee5] text-[#1a7d61]"><FileCheck2 size={20} /></div><h2 className="mt-5 font-display text-xl font-extrabold tracking-tight">Clear terms, clean handoff.</h2><p className="mt-2 text-sm leading-6 text-[#56736d]">This signing room shows the exact summary generated in the brand workspace.</p><div className="mt-6 space-y-3 text-xs font-semibold text-[#376d63]"><p className="flex gap-2"><Check size={15} />Disclosure included</p><p className="flex gap-2"><Check size={15} />Campaign-only rights</p><p className="flex gap-2"><Check size={15} />Payment timing included</p></div><button type="button" className="btn-secondary mt-6 w-full !border-[#b9d7ce]" onClick={() => setLocation('/brand')} data-testid="button-return-brand-workspace"><ArrowLeft size={14} />Return to workspace</button></div></div>}</div></main><FooterNote />{emailOpen && <EmailModal onClose={() => setEmailOpen(false)} />}</div>;
}

function SignedState({ onHome, onEmail }: { onHome: () => void; onEmail: () => void }) {
  return <div className="mx-auto max-w-xl"><div className="card bg-[#eff8f4] p-7 text-center sm:p-10"><div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[#d4eee2] text-[#18805f]"><CheckCircle2 size={33} /></div><h2 className="mt-5 font-display text-2xl font-extrabold tracking-tight">You’re all set, Maya.</h2><p className="mt-2 text-sm leading-6 text-[#54756d]">Signed on 08 October 2024 at 10:42 GST. Both sides now have a clear record.</p><div className="mt-7 grid gap-2 sm:grid-cols-2"><button type="button" className="btn-primary" onClick={() => undefined} data-testid="button-download-signed"><Download size={15} />Download copy</button><button type="button" className="btn-secondary !border-[#b9d7ce]" onClick={onEmail} data-testid="button-share-signed"><Mail size={15} />Preview share email</button></div></div><button type="button" className="mx-auto mt-6 flex items-center gap-2 text-xs font-bold text-[hsl(var(--primary))]" onClick={onHome} data-testid="button-signed-home"><ArrowLeft size={14} />Back to COMPLAINZ home</button></div>;
}

function EmailModal({ onClose, creator }: { onClose: () => void; creator?: Creator }) {
  const subject = creator ? `A creator agreement from Northstar MENA · ${creator.handle}` : 'Your COMPLAINZ review is ready';
  return <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#122438]/45 p-4"><div className="w-full max-w-lg rounded-2xl bg-white p-5 shadow-2xl sm:p-7"><div className="flex items-start justify-between"><div><p className="eyebrow">Demo fallback</p><h2 className="mt-2 font-display text-2xl font-extrabold tracking-tight">Email preview</h2></div><button type="button" className="rounded-lg p-2 hover:bg-[hsl(var(--muted))]" onClick={onClose} aria-label="Close email preview" data-testid="button-close-email-preview"><X size={18} /></button></div><div className="mt-6 rounded-xl border border-[hsl(var(--border))] bg-[#fbfcfd]"><div className="border-b border-[hsl(var(--border))] p-4 text-xs"><p><span className="font-bold text-[hsl(var(--muted-foreground))]">To</span> creator@example.com</p><p className="mt-2"><span className="font-bold text-[hsl(var(--muted-foreground))]">Subject</span> {subject}</p></div><div className="p-4 text-sm leading-6"><p>Hi there,</p><p className="mt-3">We’ve reviewed the campaign terms and prepared a clear next step. Please review the attached summary and let us know if the requested changes work for you.</p><p className="mt-3">This is a preview only — no email has been sent.</p><p className="mt-4">Thanks,<br /><strong>Northstar MENA</strong></p></div></div><div className="mt-5 flex items-center justify-between gap-3"><span className="flex items-center gap-1.5 text-[11px] text-[hsl(var(--muted-foreground))]"><Mail size={14} />No external send in demo mode</span><button type="button" className="btn-primary !px-4 !py-2.5 text-xs" onClick={onClose} data-testid="button-close-email">Close preview</button></div></div></div>;
}

function NotFound() {
  return <div className="flex min-h-[100dvh] items-center justify-center bg-[hsl(var(--background))] p-5"><div className="text-center"><Wordmark /><h1 className="mt-8 font-display text-4xl font-extrabold">That room doesn’t exist.</h1><p className="mt-3 text-sm text-[hsl(var(--muted-foreground))]">Return to the workspace and start a fresh demo.</p><Link href="/" className="btn-primary mt-6" data-testid="link-not-found-home">Back home <ArrowRight size={15} /></Link></div></div>;
}

function Router() {
  const [isBrand] = useRoute('/brand');
  const [isCreator] = useRoute('/creator');
  const [isSign] = useRoute('/sign/:id');
  return <Switch><Route path="/" component={Landing} />{isBrand && <Route path="/brand" component={BrandWorkspace} />}{isCreator && <Route path="/creator" component={CreatorWorkspace} />}{isSign && <Route path="/sign/:id" component={DemoSigningRoom} />}<Route component={NotFound} /></Switch>;
}

function App() {
  const queryClient = useMemo(() => new QueryClient(), []);
  return <QueryClientProvider client={queryClient}><Router /></QueryClientProvider>;
}

export default App;