import { PDFDocument, StandardFonts, rgb, type PDFFont, type PDFPage } from 'pdf-lib';
import type { ContractAnalysis } from '@workspace/api-client-react';

const ink = rgb(0.11, 0.17, 0.24);
const blue = rgb(0.1, 0.35, 0.59);
const gray = rgb(0.39, 0.46, 0.52);
const pageWidth = 595.28;
const pageHeight = 841.89;
const margin = 54;

function compatible(text: string) {
  const cleaned = text.normalize('NFKD')
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201c\u201d]/g, '"')
    .replace(/[\u2013\u2014]/g, '-')
    .replace(/[\u2022]/g, '-')
    .replace(/\u00a0/g, ' ')
    .replace(/[\u0000-\u001f]/g, ' ');
  if (/[^\x20-\x7E\u00A0-\u00FF\u20AC]/.test(cleaned)) {
    throw new Error('PDF export currently supports Latin-script contracts only.');
  }
  return cleaned;
}

function wrap(text: string, font: PDFFont, size: number, width: number) {
  const lines: string[] = [];
  let line = '';
  for (const word of compatible(text).split(/\s+/)) {
    const trial = line ? `${line} ${word}` : word;
    if (font.widthOfTextAtSize(trial, size) <= width) {
      line = trial;
    } else {
      if (line) lines.push(line);
      line = word;
      while (font.widthOfTextAtSize(line, size) > width && line.length > 1) {
        let split = 1;
        while (split < line.length && font.widthOfTextAtSize(line.slice(0, split + 1), size) <= width) split++;
        lines.push(line.slice(0, split));
        line = line.slice(split);
      }
    }
  }
  if (line) lines.push(line);
  return lines;
}

async function renderDocument(
  title: string,
  subtitle: string,
  sections: { heading: string; paragraphs: string[] }[],
  filename: string,
) {
  const pdf = await PDFDocument.create();
  pdf.setTitle(title);
  pdf.setCreator('COMPLAINZ');
  pdf.setSubject('Contract review draft - human review required');
  const regular = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  let page!: PDFPage;
  let y = 0;
  const startPage = () => {
    page = pdf.addPage([pageWidth, pageHeight]);
    page.drawRectangle({ x: 0, y: pageHeight - 12, width: pageWidth, height: 12, color: blue });
    page.drawText('COMPLAINZ', { x: margin, y: pageHeight - 49, size: 14, font: bold, color: ink });
    page.drawText('CONTRACT DESK', { x: pageWidth - margin - 106, y: pageHeight - 47, size: 9, font: bold, color: blue });
    page.drawLine({ start: { x: margin, y: pageHeight - 65 }, end: { x: pageWidth - margin, y: pageHeight - 65 }, thickness: 0.8, color: rgb(0.8, 0.85, 0.88) });
    y = pageHeight - 101;
  };
  const ensure = (height: number) => { if (y - height < 78) startPage(); };
  const line = (text: string, size = 10.5, weight: PDFFont = regular, color = ink, indent = 0) => {
    for (const row of wrap(text, weight, size, pageWidth - margin * 2 - indent)) {
      ensure(size + 8);
      page.drawText(row, { x: margin + indent, y, size, font: weight, color });
      y -= size + 5;
    }
  };
  startPage();
  line(title.toUpperCase(), 20, bold);
  y -= 2;
  line(subtitle, 10, regular, gray);
  y -= 20;
  for (const section of sections) {
    ensure(60);
    page.drawRectangle({ x: margin, y: y - 4, width: 4, height: 19, color: blue });
    page.drawText(compatible(section.heading.toUpperCase()), { x: margin + 14, y, size: 11, font: bold, color: blue });
    y -= 30;
    for (const paragraph of section.paragraphs) {
      line(paragraph);
      y -= 12;
    }
    y -= 7;
  }
  const count = pdf.getPageCount();
  pdf.getPages().forEach((sheet, index) => {
    sheet.drawLine({ start: { x: margin, y: 62 }, end: { x: pageWidth - margin, y: 62 }, thickness: 0.6, color: rgb(0.8, 0.85, 0.88) });
    sheet.drawText('DRAFT FOR REVIEW - NOT LEGAL ADVICE', { x: margin, y: 43, size: 8, font: bold, color: gray });
    sheet.drawText(`${index + 1} / ${count}`, { x: pageWidth - margin - 28, y: 43, size: 8, font: regular, color: gray });
  });
  const bytes = await pdf.save();
  const blob = new Blob([new Uint8Array(bytes)], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
}

export async function downloadRevisedContract(analysis: ContractAnalysis, accepted: string[]) {
  const selected = analysis.findings.filter((finding) => accepted.includes(finding.id));
  if (!selected.length) throw new Error('Select at least one suggested change to download a revised contract.');
  let revised = analysis.originalText;
  for (const finding of selected) {
    if (!revised.includes(finding.quote)) throw new Error(`Could not apply "${finding.title}" to the original text. Please retry the analysis.`);
    revised = revised.replace(finding.quote, finding.replacement);
  }
  const source = analysis.fileName.replace(/\.pdf$/i, '').replace(/[^a-z0-9-_]/gi, '-').slice(0, 80);
  await renderDocument(
    'Revised creator agreement',
    `Based on ${analysis.fileName}  |  ${selected.length} proposed change${selected.length === 1 ? '' : 's'}  |  ${new Date().toLocaleDateString()}`,
    [
      { heading: 'Review notice', paragraphs: ['This is a proposed revision generated from extracted PDF text, not an edit to the original PDF layout. Compare every clause to the source document and obtain legal review before signing.'] },
      { heading: 'Revised contract text', paragraphs: revised.split(/\n+/).filter(Boolean) },
      { heading: 'Changes made', paragraphs: selected.map((finding, index) => `${index + 1}. ${finding.title}: replaced "${finding.quote}" with "${finding.replacement}"`) },
      { heading: 'Approval', paragraphs: ['Brand / Agency: __________________________     Date: _______________', 'Creator: _________________________________     Date: _______________'] },
    ],
    `${source || 'creator-contract'}-proposed-revision.pdf`,
  );
}

export async function downloadSignedDemo(signer: string, date: string) {
  await renderDocument('Creator campaign agreement', 'Northstar MENA  /  Sara Al Nuaimi  |  FW24 Street Edit', [
    { heading: 'Parties and campaign', paragraphs: ['This demonstration agreement is between Northstar MENA (the Brand) and Sara Al Nuaimi, @sara.glow (the Creator), for the FW24 Street Edit campaign.', 'Campaign dates: 14 October - 02 November 2024. Platforms: Instagram and TikTok. Creator fee: AED 4,800.'] },
    { heading: 'Deliverables and disclosures', paragraphs: ['The Creator will publish the agreed campaign deliverables on the selected platforms. Every sponsored deliverable must clearly disclose the paid partnership in accordance with applicable rules.'] },
    { heading: 'Usage rights', paragraphs: ['The Brand may use approved deliverables only for the named campaign, on the selected platforms, during the campaign dates. Any additional use requires separate written permission.'] },
    { heading: 'Payment and exclusivity', paragraphs: ['The Brand will pay AED 4,800 within 15 business days of approval of the first deliverable. No competitor exclusivity is included unless both parties agree to it in writing.'] },
    { heading: 'Demo signature record', paragraphs: [`Electronically acknowledged by: ${signer}`, `Date: ${new Date(date).toLocaleString()}`, 'This is a sample signing experience. It is not an executed legal contract or a verified identity record.'] },
  ], 'COMPLAINZ-demo-creator-agreement.pdf');
}