import { useRef, useState, type DragEvent } from 'react';
import type { ContractAnalysis } from '@workspace/api-client-react';
import { ArrowLeft, Check, ChevronDown, CloudUpload, Download, FileText, LoaderCircle, Mail, ShieldAlert, X } from 'lucide-react';
import { downloadRevisedContract } from './contract-pdf';

type UploadProps = { onBack: () => void; onAnalyzed: (result: ContractAnalysis) => void };

export function CreatorPdfUpload({ onBack, onAnalyzed }: UploadProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const choose = (candidate?: File) => {
    setError('');
    if (!candidate) return;
    if (candidate.type !== 'application/pdf' && !candidate.name.toLowerCase().endsWith('.pdf')) {
      setError('Choose a PDF contract.');
      return;
    }
    if (candidate.size > 8 * 1024 * 1024) {
      setError('PDF must be 8 MB or smaller.');
      return;
    }
    setFile(candidate);
  };
  const drop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    if (!busy) choose(event.dataTransfer.files[0]);
  };
  const analyze = async () => {
    if (!file || busy) return;
    setBusy(true);
    setError('');
    try {
      const form = new FormData();
      form.append('file', file);
      const response = await fetch('/api/contracts/analyze', { method: 'POST', body: form });
      const data: unknown = await response.json();
      if (!response.ok) {
        const failure = data as { error?: string };
        throw new Error(failure.error || 'Analysis failed. Please retry.');
      }
      onAnalyzed(data as ContractAnalysis);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Could not analyze this PDF.');
    } finally {
      setBusy(false);
    }
  };
  return <div className="grid gap-5 lg:grid-cols-[1fr_330px]">
    <div className="card p-5 sm:p-7">
      <p className="eyebrow">Your contract</p>
      <h1 className="mt-2 font-display text-2xl font-extrabold tracking-tight">Upload your PDF for an AI review</h1>
      <p className="mt-2 text-sm leading-6 text-[hsl(var(--muted-foreground))]">We extract the text, identify specific clauses to negotiate, and prepare a revised draft you can download.</p>
      <input ref={inputRef} type="file" accept=".pdf,application/pdf" className="sr-only" aria-label="Upload contract PDF" data-testid="input-contract-pdf" onChange={(event) => choose(event.target.files?.[0])} />
      <div onDragOver={(event) => event.preventDefault()} onDrop={drop} className="mt-6 rounded-xl border-2 border-dashed border-[#a8c8d3] bg-[#f8fbfc] p-8 text-center">
        <CloudUpload size={31} className="mx-auto text-[#27718a]" />
        <p className="mt-3 text-sm font-bold">{file ? file.name : 'Drop your PDF contract here'}</p>
        <p className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">{file ? `${(file.size / 1024 / 1024).toFixed(2)} MB selected` : 'Text-based PDF, up to 8 MB and 25 pages'}</p>
        <button type="button" disabled={busy} className="btn-secondary mt-4" onClick={() => inputRef.current?.click()} data-testid="button-upload-contract">{file ? 'Choose a different PDF' : 'Choose PDF'}</button>
      </div>
      {error && <p role="alert" className="mt-4 rounded-lg bg-[#fff0ed] p-3 text-sm text-[#a44338]">{error}</p>}
      <p className="mt-4 text-xs leading-5 text-[hsl(var(--muted-foreground))]">Uploaded text is sent to the AI provider for analysis and is not saved in this app. Scanned PDFs without selectable text are not supported, and revised PDF export currently supports Latin-script text. Review AI suggestions with a qualified professional before signing.</p>
      <div className="mt-6 flex justify-between border-t border-[hsl(var(--border))] pt-5"><button type="button" className="btn-secondary" disabled={busy} onClick={onBack}><ArrowLeft size={16} />Back</button><button type="button" className="btn-primary disabled:opacity-50" disabled={!file || busy} onClick={analyze} data-testid="button-upload-analyze">{busy ? <LoaderCircle size={16} className="animate-spin" /> : <FileText size={16} />}{busy ? 'Analyzing PDF…' : 'Analyze contract'}</button></div>
    </div>
    <div className="card h-fit bg-[#eff7f7] p-5 sm:p-6">
      <p className="eyebrow">What you receive</p>
      <h2 className="mt-2 font-display text-xl font-extrabold">Specific, source-backed suggestions</h2>
      <p className="mt-3 text-sm leading-6 text-[hsl(var(--muted-foreground))]">Each suggestion quotes your actual contract and proposes replacement wording. Select the changes you want before downloading a revised PDF draft.</p>
    </div>
  </div>;
}

type AnalysisProps = { analysis: ContractAnalysis; accepted: string[]; setAccepted: (ids: string[]) => void; onBack: () => void };

export function CreatorPdfAnalysis({ analysis, accepted, setAccepted, onBack }: AnalysisProps) {
  const [open, setOpen] = useState<string | null>(analysis.findings[0]?.id ?? null);
  const [error, setError] = useState('');
  const [downloading, setDownloading] = useState(false);
  const [emailOpen, setEmailOpen] = useState(false);
  const selected = analysis.findings.filter((finding) => accepted.includes(finding.id));
  const responseText = `Hello,\n\nI have reviewed ${analysis.fileName} and would like to discuss the following changes before signing:\n\n${selected.map((finding, index) => `${index + 1}. ${finding.title}: ${finding.replacement}`).join('\n\n')}\n\nPlease let me know if we can agree to these terms.\n\nThank you`;
  const download = async () => {
    setError('');
    setDownloading(true);
    try { await downloadRevisedContract(analysis, accepted); }
    catch (reason) { setError(reason instanceof Error ? reason.message : 'Could not create the revised PDF.'); }
    finally { setDownloading(false); }
  };
  const toggle = (id: string) => setAccepted(accepted.includes(id) ? accepted.filter((item) => item !== id) : [...accepted, id]);
  return <div className="space-y-5">
    <div className="grid gap-5 lg:grid-cols-[1fr_330px]">
      <div className="card p-5 sm:p-7">
        <p className="eyebrow">AI review of your uploaded PDF</p>
        <h1 className="mt-2 font-display text-2xl font-extrabold tracking-tight">Contract analysis</h1>
        <p className="mt-2 text-xs text-[hsl(var(--muted-foreground))]">{analysis.fileName} · {analysis.findings.length} source-backed suggestion{analysis.findings.length === 1 ? '' : 's'}</p>
        <p className="mt-5 rounded-lg bg-[#f2f8fa] p-4 text-sm leading-6">{analysis.summary}</p>
        {analysis.findings.length === 0 && <p className="mt-5 text-sm text-[hsl(var(--muted-foreground))]">No exact-match changes were suggested. Review the original contract yourself before signing.</p>}
        <div className="mt-5 space-y-3">{analysis.findings.map((finding) => <div key={finding.id} className="rounded-xl border border-[hsl(var(--border))]">
          <button type="button" onClick={() => setOpen(open === finding.id ? null : finding.id)} className="flex w-full items-center justify-between gap-3 p-4 text-left"><span className="flex items-center gap-2 text-sm font-bold"><ShieldAlert size={16} className={finding.severity === 'high' ? 'text-[#b44b3e]' : 'text-[#a46c14]'} />{finding.title}</span><ChevronDown size={16} className={open === finding.id ? 'rotate-180' : ''} /></button>
          {open === finding.id && <div className="border-t border-[hsl(var(--border))] px-4 pb-4 pt-3">
            <p className="text-[10px] font-bold uppercase tracking-wide text-[hsl(var(--muted-foreground))]">{finding.severity} priority · From your PDF</p>
            <blockquote className="mt-2 border-l-2 border-[#d5a13b] pl-3 text-xs italic leading-5">“{finding.quote}”</blockquote>
            <p className="mt-3 text-xs leading-5 text-[hsl(var(--muted-foreground))]">{finding.explanation}</p>
            <div className="mt-3 rounded-lg bg-[#f2f8fa] p-3 text-xs leading-5"><strong>Proposed replacement: </strong>{finding.replacement}</div>
            <button type="button" className="btn-secondary mt-3 !px-3 !py-2 text-xs" onClick={() => toggle(finding.id)} data-testid={`button-accept-finding-${finding.id}`}><Check size={14} />{accepted.includes(finding.id) ? 'Included in revised contract' : 'Include this change'}</button>
          </div>}
        </div>)}</div>
      </div>
      <div className="card h-fit p-5 sm:p-6"><p className="eyebrow">Your next step</p><h2 className="mt-2 font-display text-xl font-extrabold">Download your revised draft</h2><p className="mt-3 text-xs leading-5 text-[hsl(var(--muted-foreground))]">{selected.length} of {analysis.findings.length} changes selected. The generated PDF contains the extracted original contract text with selected clauses replaced, plus a change register. Original formatting may differ.</p>
        <button type="button" disabled={!selected.length || downloading} className="btn-primary mt-5 w-full disabled:opacity-50" onClick={download} data-testid="button-download-revised-contract">{downloading ? <LoaderCircle size={15} className="animate-spin" /> : <Download size={15} />}{downloading ? 'Preparing PDF…' : 'Download revised contract'}</button>
        <button type="button" disabled={!selected.length} className="btn-secondary mt-2 w-full disabled:opacity-50" onClick={() => setEmailOpen(true)} data-testid="button-preview-response"><Mail size={15} />Preview response email</button>
        {error && <p role="alert" className="mt-3 text-xs text-[#a44338]">{error}</p>}
        <p className="mt-4 text-[11px] leading-5 text-[hsl(var(--muted-foreground))]">AI suggestions are not legal advice. No email is sent and the document is a proposed draft, not a signed agreement.</p>
      </div>
    </div>
    <button type="button" className="btn-secondary" onClick={onBack}><ArrowLeft size={16} />Back to upload</button>
    {emailOpen && <div role="dialog" aria-modal="true" aria-label="Response email preview" className="fixed inset-0 z-50 flex items-center justify-center bg-[#122438]/45 p-4"><div className="card max-h-[85vh] w-full max-w-xl overflow-auto p-6"><div className="flex items-center justify-between"><h2 className="font-display text-xl font-extrabold">Response email preview</h2><button type="button" aria-label="Close email preview" onClick={() => setEmailOpen(false)}><X size={18} /></button></div><pre className="mt-5 whitespace-pre-wrap rounded-lg bg-[#f8fafb] p-4 font-sans text-sm leading-6">{responseText}</pre><p className="mt-3 text-xs text-[hsl(var(--muted-foreground))]">Preview only — no email sent.</p><button type="button" className="btn-secondary mt-4" onClick={() => setEmailOpen(false)}>Close</button></div></div>}
  </div>;
}