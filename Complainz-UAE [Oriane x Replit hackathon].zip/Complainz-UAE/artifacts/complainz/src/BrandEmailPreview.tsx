import { useState } from 'react';
import { ClipboardCopy, Mail, X } from 'lucide-react';

type Campaign = {
  name: string;
  fee: string;
  start: string;
  end: string;
  usage: boolean;
  exclusivity: boolean;
  platforms: string[];
};

export function BrandEmailPreview({ creatorHandle, campaign, onClose }: { creatorHandle: string; campaign: Campaign; onClose: () => void }) {
  const [error, setError] = useState('');
  const subject = `${campaign.name} — creator agreement for ${creatorHandle}`;
  const body = `Hello,\n\nPlease review our draft for ${campaign.name}:\n\nCreator: ${creatorHandle}\nFee: AED ${Number(campaign.fee).toLocaleString()}\nDates: ${campaign.start} to ${campaign.end}\nPlatforms: ${campaign.platforms.join(', ') || 'To be agreed'}\nUsage: ${campaign.usage ? 'Campaign channels and dates only' : 'Creator organic channels only'}\nExclusivity: ${campaign.exclusivity ? 'Named competitors during the campaign' : 'None'}\n\nThis is a demo draft. Please verify all terms and permits before signing.\n\nThank you`;
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(`Subject: ${subject}\n\n${body}`);
      setError('');
      onClose();
    } catch {
      setError('Clipboard access is unavailable. Select and copy the draft text instead.');
    }
  };
  return <div role="dialog" aria-modal="true" aria-label="Email draft preview" className="fixed inset-0 z-50 flex items-center justify-center bg-[#122438]/45 p-4">
    <div className="card max-h-[90vh] w-full max-w-lg overflow-auto p-5 sm:p-7">
      <div className="flex items-start justify-between gap-4"><div><p className="eyebrow">Your campaign details</p><h2 className="mt-2 font-display text-2xl font-extrabold">Email draft</h2></div><button type="button" className="rounded-lg p-2 hover:bg-[hsl(var(--muted))]" onClick={onClose} aria-label="Close email preview" data-testid="button-close-email-preview"><X size={18} /></button></div>
      <p className="mt-3 text-xs leading-5 text-[hsl(var(--muted-foreground))]">No recipient is assumed, and no email is sent by COMPLAINZ. The buttons below copy this draft or open it in your email app.</p>
      <div className="mt-5 rounded-xl border border-[hsl(var(--border))] bg-[#fbfcfd] p-4 text-sm"><p><strong>Subject:</strong> {subject}</p><pre className="mt-4 whitespace-pre-wrap border-t border-[hsl(var(--border))] pt-4 font-sans leading-6">{body}</pre></div>
      {error && <p role="alert" className="mt-3 text-xs text-[#a44338]">{error}</p>}
      <div className="mt-5 flex flex-wrap gap-2"><button type="button" className="btn-secondary" onClick={copy} data-testid="button-copy-email-draft"><ClipboardCopy size={15} />Copy draft</button><a className="btn-primary" href={`mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`} data-testid="link-open-email-app"><Mail size={15} />Open email app</a><button type="button" className="btn-secondary" onClick={onClose}>Close</button></div>
    </div>
  </div>;
}