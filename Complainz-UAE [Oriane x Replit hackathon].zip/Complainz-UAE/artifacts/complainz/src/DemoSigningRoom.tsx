import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { ArrowLeft, CheckCircle2, Download, FileText, PenLine, ShieldCheck } from 'lucide-react';
import { downloadSignedDemo } from './contract-pdf';

export default function DemoSigningRoom() {
  const [, setLocation] = useLocation();
  const [signer, setSigner] = useState(() => localStorage.getItem('complainz-demo-signer') || '');
  const [signedAt, setSignedAt] = useState(() => localStorage.getItem('complainz-demo-signed-at') || '');
  const [agreed, setAgreed] = useState(false);
  const [error, setError] = useState('');
  const sign = () => {
    const time = new Date().toISOString();
    localStorage.setItem('complainz-demo-signer', signer.trim());
    localStorage.setItem('complainz-demo-signed-at', time);
    setSignedAt(time);
  };
  const download = async () => {
    setError('');
    try { await downloadSignedDemo(signer, signedAt); }
    catch (reason) { setError(reason instanceof Error ? reason.message : 'Could not generate the contract PDF.'); }
  };
  return <div className="app-shell min-h-[100dvh]">
    <header className="flex items-center justify-between border-b border-[hsl(var(--border))] bg-white px-5 py-5 sm:px-10">
      <Link href="/" className="font-display text-lg font-extrabold tracking-tight text-[#172536]">COMPLAINZ</Link>
      <span className="flex items-center gap-1.5 text-xs font-bold text-[#197b62]"><ShieldCheck size={15} />Demo signing room</span>
    </header>
    <main className="mx-auto max-w-4xl px-4 py-8 sm:px-8 sm:py-12">
      <div className="mb-7 flex flex-wrap items-center justify-between gap-4"><div><p className="eyebrow">Northstar MENA · Creator agreement</p><h1 className="mt-2 font-display text-3xl font-extrabold tracking-tight">{signedAt ? 'Agreement acknowledged' : 'Review before you sign'}</h1><p className="mt-2 text-sm text-[hsl(var(--muted-foreground))]">This is a sample contract and signing experience, not a legally executed agreement.</p></div><span className="rounded-full bg-[#eaf7f1] px-3 py-2 text-xs font-bold text-[#187959]">{signedAt ? 'Demo signed' : 'Awaiting review'}</span></div>
      <div className="grid gap-5 lg:grid-cols-[1fr_250px]">
        <article className="card overflow-hidden bg-white">
          <div className="border-t-[6px] border-[#2471a9] px-6 pb-7 pt-8 sm:px-10">
            <div className="flex items-center justify-between gap-3 border-b border-[hsl(var(--border))] pb-5"><span className="font-display text-lg font-extrabold">COMPLAINZ</span><span className="text-[10px] font-bold tracking-[.18em] text-[#31718d]">CONTRACT DESK</span></div>
            <p className="mt-8 text-[10px] font-bold uppercase tracking-[.18em] text-[#397395]">Creator campaign agreement · demo</p>
            <h2 className="mt-2 font-display text-2xl font-extrabold">FW24 Street Edit</h2>
            <div className="mt-7 grid gap-3 rounded-lg bg-[#f4f8fa] p-4 text-xs sm:grid-cols-2"><p><strong>Brand</strong><br />Northstar MENA</p><p><strong>Creator</strong><br />Sara Al Nuaimi · @sara.glow</p><p><strong>Fee</strong><br />AED 4,800</p><p><strong>Campaign period</strong><br />14 Oct – 02 Nov 2024</p></div>
            <div className="mt-8 space-y-6 text-sm leading-7 text-[#354657]">
              <section><h3 className="mb-1 font-display font-extrabold text-[#172536]">01 / Deliverables & disclosure</h3><p>Agreed content is published to Instagram and TikTok. Every sponsored deliverable must clearly disclose the paid partnership.</p></section>
              <section><h3 className="mb-1 font-display font-extrabold text-[#172536]">02 / Usage rights</h3><p>Approved content may be used only for the named campaign, selected channels, and campaign dates. Additional use requires separate written permission.</p></section>
              <section><h3 className="mb-1 font-display font-extrabold text-[#172536]">03 / Payment & exclusivity</h3><p>AED 4,800 is due within 15 business days of approval of the first deliverable. No competitor exclusivity applies without a separate written agreement.</p></section>
            </div>
            <div className="mt-8 grid gap-6 border-t border-[hsl(var(--border))] pt-6 text-xs sm:grid-cols-2"><div><p className="font-bold">Brand representative</p><div className="mt-6 border-b border-[#9aaeb8]" /><p className="mt-2 text-[hsl(var(--muted-foreground))]">Name / signature</p></div><div><p className="font-bold">Creator acknowledgement</p><p className="mt-6 border-b border-[#9aaeb8] pb-1 font-semibold">{signedAt ? signer : ' '}</p><p className="mt-2 text-[hsl(var(--muted-foreground))]">{signedAt ? new Date(signedAt).toLocaleString() : 'Name / signature'}</p></div></div>
          </div>
        </article>
        <aside className="card h-fit p-5">
          {signedAt ? <><CheckCircle2 size={29} className="text-[#187959]" /><h2 className="mt-3 font-display text-lg font-extrabold">Your demo copy is ready</h2><p className="mt-2 text-xs leading-5 text-[hsl(var(--muted-foreground))]">Download a multi-section PDF with the agreement terms, signature record, and page numbers.</p><button type="button" className="btn-primary mt-5 w-full" onClick={download} data-testid="button-download-signed"><Download size={16} />Download contract PDF</button></> : <><FileText size={27} className="text-[#27718a]" /><h2 className="mt-3 font-display text-lg font-extrabold">Acknowledge the demo</h2><label className="mt-5 block text-xs font-bold">Your full name<input className="field mt-2" value={signer} onChange={(event) => setSigner(event.target.value)} placeholder="Your full name" data-testid="input-signature-name" /></label><label className="mt-4 flex gap-2 text-xs leading-5"><input type="checkbox" checked={agreed} onChange={(event) => setAgreed(event.target.checked)} data-testid="checkbox-signature-agreement" /><span>I have reviewed this sample agreement.</span></label><button type="button" className="btn-primary mt-5 w-full disabled:opacity-50" disabled={signer.trim().length < 3 || !agreed} onClick={sign} data-testid="button-complete-signature"><PenLine size={16} />Complete demo signature</button></>}
          {error && <p role="alert" className="mt-3 text-xs text-[#a44338]">{error}</p>}
          <button type="button" onClick={() => setLocation('/brand')} className="btn-secondary mt-3 w-full"><ArrowLeft size={15} />Back to brand</button>
          <p className="mt-5 text-[11px] leading-5 text-[hsl(var(--muted-foreground))]">The PDF is a demo document. Have a lawyer review any real agreement before signing.</p>
        </aside>
      </div>
    </main>
  </div>;
}