import { Router, type IRouter } from "express";
import {
  LookupOrianeBody,
  LookupOrianeResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const ORIANE_BASE_URL = process.env["ORIANE_BASE_URL"] || "https://connect.oriane.xyz";

type UnknownRecord = Record<string, unknown>;

function asRecord(value: unknown): UnknownRecord {
  return value && typeof value === "object" ? (value as UnknownRecord) : {};
}

function asNumber(value: unknown, fallback = 0) {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

function asString(value: unknown, fallback = "") {
  return typeof value === "string" ? value : fallback;
}

function asStringOrNull(value: unknown) {
  return typeof value === "string" ? value : null;
}

function normalizeHandle(handle: string) {
  return handle.trim().replace(/^@/, "");
}

function normalizeList(value: unknown) {
  if (!Array.isArray(value)) return [];
  return value
    .map((item) => {
      if (typeof item === "string") return item;
      const record = asRecord(item);
      return asString(record["handle"] ?? record["displayName"] ?? record["name"]);
    })
    .filter(Boolean);
}

function threeMonthsAgo() {
  const date = new Date();
  date.setUTCMonth(date.getUTCMonth() - 3);
  return date.toISOString().slice(0, 10);
}

async function orianeRequest(path: string, body: UnknownRecord, apiKey: string) {
  const response = await fetch(`${ORIANE_BASE_URL}${path}`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });
  const payload: unknown = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = asRecord(payload);
    const nestedError = asRecord(error["error"]);
    throw new Error(
      asString(nestedError["message"] ?? error["message"], `Oriane returned ${response.status}`),
    );
  }
  return asRecord(payload);
}

function normalizeProfile(raw: UnknownRecord, platform: string) {
  return {
    id: asString(raw["id"]),
    handle: asString(raw["handle"]),
    displayName: asString(raw["displayName"], asString(raw["handle"])),
    platform: asString(raw["platform"], platform),
    platformId: asStringOrNull(raw["platformId"]),
    profilePictureUrl: asStringOrNull(raw["profilePictureUrl"]),
    publicEmail: asStringOrNull(raw["publicEmail"]),
    followersCount: asNumber(raw["followersCount"]),
    followingCount: asNumber(raw["followingCount"]),
    postsCount: asNumber(raw["postsCount"]),
    isVerified: raw["isVerified"] === true,
    bio: asStringOrNull(raw["bio"]),
  };
}

function normalizeVideo(raw: UnknownRecord, platform: string) {
  return {
    id: asString(raw["id"]),
    platform: asString(raw["platform"], platform),
    videoUrl: asStringOrNull(raw["url"] ?? raw["videoUrl"]),
    thumbnailUrl: asStringOrNull(raw["thumbnailMediaUrl"]),
    publishDate: asString(raw["publishedAt"], new Date().toISOString()),
    caption: asStringOrNull(raw["caption"]),
    views: asNumber(raw["viewsCount"]),
    likes: asNumber(raw["likesCount"]),
    comments: asNumber(raw["commentsCount"]),
    saves: asNumber(raw["savesCount"]),
    erPerViews: asNumber(raw["engagementRatePerViews"]),
    erPerFollowers: asNumber(raw["engagementRatePerFollowers"]),
    accountUsername: asString(raw["profileHandle"]),
    followerCount: asNumber(raw["profileFollowersCount"]),
    verified: raw["profileVerified"] === true,
    coAuthors: normalizeList(raw["coAuthors"]),
    mentions: normalizeList(raw["mentions"]),
    transcript: asStringOrNull(raw["transcript"]),
  };
}

router.post("/oriane/lookup", async (req, res) => {
  const parsed = LookupOrianeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Handle and platform are required." });
    return;
  }

  const apiKey = process.env["ORIANE_API_KEY"];
  if (!apiKey) {
    res.status(503).json({ error: "ORIANE_API_KEY is not configured." });
    return;
  }

  const handle = normalizeHandle(parsed.data.handle);
  const platform = parsed.data.platform;
  if (!/^[a-zA-Z0-9._]{1,80}$/.test(handle)) {
    res.status(400).json({ error: "Enter a valid Instagram or TikTok handle." });
    return;
  }

  try {
    const profilePayload = await orianeRequest(
      "/rest/profiles/search?projection=full&limit=1",
      {
        operator: "and",
        filters: {
          handle: { exactMatch: { values: [handle] } },
          platform: { includes: [platform] },
          followersCount: { min: 5000 },
        },
      },
      apiKey,
    );
    const rawProfile = Array.isArray(profilePayload["data"])
      ? asRecord(profilePayload["data"][0])
      : {};

    const contentPayload = await orianeRequest(
      `/rest/contents/search?projection=full&limit=10&sort=publishedAt:desc`,
      {
        operator: "and",
        filters: {
          profileHandle: { exactMatch: { values: [handle] } },
          platform: { includes: [platform] },
          profileFollowersCount: { min: 5000 },
          publishedAt: { after: threeMonthsAgo() },
        },
      },
      apiKey,
    );
    const rawVideos = Array.isArray(contentPayload["data"])
      ? contentPayload["data"].map(asRecord)
      : [];

    const profile = rawProfile["id"]
      ? normalizeProfile(rawProfile, platform)
      : rawVideos[0]?.["profileId"]
        ? normalizeProfile({
            id: rawVideos[0]["profileId"],
            handle: rawVideos[0]["profileHandle"],
            displayName: rawVideos[0]["profileDisplayName"],
            platform: rawVideos[0]["platform"],
            platformId: rawVideos[0]["profilePlatformId"],
            profilePictureUrl: rawVideos[0]["profilePictureUrl"],
            publicEmail: null,
            followersCount: rawVideos[0]["profileFollowersCount"],
            followingCount: rawVideos[0]["profileFollowingCount"],
            postsCount: rawVideos[0]["profilePostsCount"],
            isVerified: rawVideos[0]["profileVerified"],
            bio: rawVideos[0]["profileBio"],
          }, platform)
        : null;

    const response = LookupOrianeResponse.parse({
      source: "oriane",
      live: true,
      profile,
      videos: rawVideos.map((video) => normalizeVideo(video, platform)),
      dataLimits: {
        lookback: "Last 3 months",
        platforms: ["Instagram", "TikTok"],
        minimumFollowers: 5000,
      },
    });
    res.json(response);
  } catch (error) {
    req.log.error({ err: error, handle, platform }, "Oriane lookup failed");
    res.status(502).json({
      error: error instanceof Error ? error.message : "Oriane lookup failed.",
    });
  }
});

export default router;