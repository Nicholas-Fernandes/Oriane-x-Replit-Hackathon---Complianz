import { Router, type IRouter } from "express";
import healthRouter from "./health";
import orianeRouter from "./oriane";
import contractsRouter from "./contracts";

const router: IRouter = Router();

router.use(healthRouter);
router.use(orianeRouter);
router.use(contractsRouter);

export default router;
